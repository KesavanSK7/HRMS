package servlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/api/login")
public class LoginServlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;
	    private Gson gson = new Gson();

	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        String email = request.getParameter("email");
	        String pass = request.getParameter("pass");

	        response.setContentType("application/json");

	        Connection conn = null;
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrms", "root", "Kesavan@2003");

	            PreparedStatement ps = conn.prepareStatement("SELECT emp_id, emp_name, pass FROM Employee WHERE email = ?");
	            ps.setString(1, email);
	            ResultSet rs = ps.executeQuery();

	            if (rs.next()) {
	                String storedPass = rs.getString("pass");
	                if (!pass.equals(storedPass)) {
	                    ErrorResponse error = new ErrorResponse("Incorrect password");
	                    response.getWriter().write(gson.toJson(error));
	                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
	                } else {
	                    // Password correct, return success response
	                    SuccessResponse success = new SuccessResponse("Login successful");
	                    response.getWriter().write(gson.toJson(success));
	                    response.setStatus(HttpServletResponse.SC_OK);
	                }
	            } else {
	                ErrorResponse error = new ErrorResponse("User not found");
	                response.getWriter().write(gson.toJson(error));
	                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
	            }
	        } catch (Exception e) {
	            ErrorResponse error = new ErrorResponse("Server error");
	            response.getWriter().write(gson.toJson(error));
	            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	        }
	    }

	    class ErrorResponse {
	        private String error;

	        public ErrorResponse(String error) {
	            this.error = error;
	        }

	        public String getError() {
	            return error;
	        }
	    }
	    class SuccessResponse {
	        private String message;

	        public SuccessResponse(String message) {
	            this.message = message;
	        }

	        public String getMessage() {
	            return message;
	        }
	    }

}
