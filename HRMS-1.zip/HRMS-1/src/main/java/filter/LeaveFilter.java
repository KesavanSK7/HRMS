package filter;

import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javafile.DBConnection;

import java.sql.*;

/**
 * Servlet Filter implementation class LeaveFilter
 */
//@WebFilter("/leave")
public class LeaveFilter extends HttpFilter implements Filter {

    public LeaveFilter() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void destroy() {
		// TODO Auto-generated method stub
	}

	Connection conn = null;
	PreparedStatement ps = null;
	int sessionID = 0;
	HttpSession session = null;
	boolean t = true;
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		session = req.getSession();
		sessionID = (int)session.getAttribute("emp_id");
		
		String path = req.getPathInfo();
		System.out.println(req.getPathInfo());
		
		
		if(path.equals("/applyleave")) {
			applyLeave(req,res);
			System.out.println("apply leave");
		}
		else if(path.equals("/viewleaves")) {
			//viewLeaves(req,res);
			System.out.println("view leaves");
		}
		else if(path.equals("/setleave")) {
			setLeave(req,res);
			System.out.println("set leave");
		}
		else if(path.equals("/approveleave")) {
			approveLeave(req,res);
			System.out.println("approve leave");
			
		}
		if(t)
		chain.doFilter(request, response);
	}

	public void approveLeave(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stubs
		
		
	}

	public void setLeave(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		// TODO Auto-generated method stub
		System.out.println("Entered");
		if(!validEmployee(req, res, "setLeave")) {
			processError(req, res, "Invalid Employee");
		} else {
			System.out.println("setLeave Filter executed");
		}
	}

	public void processError(HttpServletRequest req, HttpServletResponse res, String errorMsg) throws IOException, ServletException {
		// TODO Auto-generated method stub
		System.out.println("Invalid Employee msg");
		t = false;
		HttpSession session = req.getSession();
		session.setAttribute("leaveError", errorMsg);
		req.getRequestDispatcher("../leave.jsp").forward(req, res);
	}

	private boolean validEmployee(HttpServletRequest req, HttpServletResponse res, String type) {
		// TODO Auto-generated method stub
		int id = 0;
		//if(type.equals("setLeave") || type.equals("viewLeaves"))
		id = Integer.parseInt(req.getParameter("leave_emp_id"));
		try {
			conn = DBConnection.getConnection();
			ps = conn.prepareStatement("select * from Employee where emp_id = ?");
			ps.setInt(1,id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				return true;
			}
			else {
				return false;
			}
		} catch(Exception e) {
			System.out.println("Valid Employee error");
		}
		return false;
	}

	public void viewLeaves(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(req.getParameter("leave_emp_id"));
		if(!validEmployee(req, res, "viewLeaves")) {
			t = false;
			processError(req,res,"Invalid Employee");
		}
	}

	public void applyLeave(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		// TODO Auto-generated method stub
		int id = sessionID;
		String leaveType = req.getParameter("leavetype");
		Date startDate = Date.valueOf(req.getParameter("startdate"));
		Date endDate = Date.valueOf(req.getParameter("enddate"));
		String reason = req.getParameter("reason");
		
		int totalLeaves = 0;
		int leaveTypeDays = 0;
		if(startDate.after(endDate)) {
			t = false;
			System.out.println("Start date should be less than end date");
			processError(req,res,"Start date should be less than end date");
		} else {
			try {
			conn = DBConnection.getConnection();
			ps = conn.prepareStatement("select sum(datediff(end_date,start_date)) as days from LeaveRecord where emp_id = ? and status = 'approved' and leave_type = ?");
			ps.setInt(1, id);
			ps.setString(2,leaveType);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				totalLeaves = rs.getInt("days");
			}
			ps = conn.prepareStatement("select leave_type_days from LeaveBalance where leave_type = ? and emp_id = ?");
			ps.setString(1,leaveType);
			ps.setInt(2, id);
			rs = ps.executeQuery();
			if(rs.next()) {
				leaveTypeDays = rs.getInt("leave_type_days");
			}
			LocalDate startD = startDate.toLocalDate();
			LocalDate endD = endDate.toLocalDate();

			// Calculate the difference in days
			long daysBetween = ChronoUnit.DAYS.between(startD, endD);
			System.out.println("Days between :"+daysBetween+" LeaveTypeDays :"+leaveTypeDays+" Total Leaves : "+totalLeaves);
			if(daysBetween > Math.abs((leaveTypeDays - totalLeaves))) { //greater
				t = true;
				System.out.println("Added to LOP");
				session.setAttribute("LOP","LOP");
				//processError(req,res,"Cannot apply leave");
			}
			} catch(Exception e) {
				System.out.println("applyLeave Filter error "+e.getMessage());
			}
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
