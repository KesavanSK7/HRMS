package servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        // Read input JSON from request
        JsonReader jsonReader = Json.createReader(request.getReader());
        JsonObject jsonObject = jsonReader.readObject();
        String email = jsonObject.getString("email");
        String password = jsonObject.getString("password");

        Connection conn = null;
        boolean success = false;
        String message = "Invalid credentials";
        
        int empId = 0;
        String empName = "";
        String designation = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrms", "root", "Kesavan@2003");

            PreparedStatement ps = conn.prepareStatement("SELECT e.emp_id, e.emp_name, d.designation, e.pass FROM Employee e inner join Designation d on e.desig_id = d.desig_id  WHERE email = ?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String userPass = rs.getString("pass");
                empName = rs.getString("emp_name");
                empId = rs.getInt("emp_id");
                designation = rs.getString("designation");
                
                if (password.equals(userPass)) {
                    success = true;
                    message = "Login successful";
                } else {
                    message = "Password is incorrect";
                }
            } else {
                message = "User not found";
            }
        } catch (Exception e) {
            e.printStackTrace();
            message = "An error occurred";
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        //session.setAttribute("emp_id", empId);
        //session.setAttribute("emp_name",empName);
        //session.setAttribute("email", email);
        //session.setAttribute("designation", designation);
        

        // Create response JSON
        JsonObject responseJson = Json.createObjectBuilder()
                .add("success", success)
                .add("message", message)
                .add("emp_id", empId)
                .add("emp_name", empName)
                .add("email", email)
                .add("designation", designation)
                .build();

        // Write response JSON
        out.print(responseJson.toString());
    }
}
