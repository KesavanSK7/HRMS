package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import java.sql.*;
import java.sql.Date;
import java.util.*;
import javafile.Employee;
import javafile.Others;
import javafile.DBConnection;

/**
 * Servlet implementation class OthersServlet
 */
@WebServlet("/others")
public class OthersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public OthersServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
	HttpSession session = null;
	Connection conn = DBConnection.getConnection();
	PreparedStatement ps = null;
	ResultSet rs = null;
	int sessionId = 0;
	String designation = "";
	int managerId = 0;
	int editEmpId = 0;
	
	static Map<Integer, Employee> empMap = new HashMap<>(); 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		session = request.getSession();
		//sessionId = (int)session.getAttribute("emp_id");
		
		
		String type = request.getParameter("input_type");
		System.out.println(type);
		if(type.equals("view_employee")) {
			System.out.println("View Employee");
			designation = request.getParameter("designation");
			managerId = Integer.parseInt(request.getParameter("manager_id"));
			viewEmployee(request, response);
		} else if (type.equals("edit_employee")) {
            int empId = Integer.parseInt(request.getParameter("edit_emp_id"));
            loadEmployee(empId, request, response);
        } else if (type.equals("update_employee")) {
        	editEmpId = Integer.parseInt(request.getParameter("edit_emp_id"));
        	managerId = Integer.parseInt(request.getParameter("manager_id"));
            updateEmployee(request, response);
        }
	}
	
	private void updateEmployee(HttpServletRequest request, HttpServletResponse response) {
	    
	    Employee emp = (Employee)session.getAttribute("editEmployee");
	    String gender = request.getParameter("gender");
	    if(!gender.equals("M") && !gender.equals("F"))
	    	gender = null;
	    
	    String phno = request.getParameter("phone_number");
	    if(phno.equals(""))
	    	phno = null;
	    
	    Date dob = null;
	    Date doj = null;
	    String dob1 = (String)request.getParameter("DOB");
	    String doj1 = (String)request.getParameter("DOJ"); 
	    
	    if(!dob1.equals(""))
	    	dob = Date.valueOf(request.getParameter("DOB"));
	    System.out.println("DOB :" + dob);
	    
	    if(!doj1.equals(""))
	    	doj = Date.valueOf(request.getParameter("DOJ"));
	    
	    String qualification = request.getParameter("qualification");
	    if(qualification.equals(""))
	    	qualification = null;
	    
	    String experience = request.getParameter("experience");
	    if(experience.equals(""))
	    	experience = null;
	    
	    String yoe1 = request.getParameter("year_of_experience");
	    int yoe = 0;
	    if(!yoe1.equals(""))
	    	yoe = Integer.parseInt(yoe1);
	    
	    System.out.println(gender);
	    
	    emp.setGender(gender);
	    emp.setPhoneNumber(phno);
	    emp.setDob(dob);
	    emp.setQualification(qualification);
	    emp.setExperience(experience);
	    emp.setYoe(yoe);
	    emp.setDoj(doj);
	    System.out.println(emp.getPhoneNumber()==null?"null":emp.getPhoneNumber());

	    try {
	    	String sql = "UPDATE Employee SET DOB = ?, gender = ?, "
	    			+ "phone_number = ?, DOJ = ?, qualification = ?, "
	    			+ "experience = ?, year_of_experience = ?, modified_by = ? "
	    			+ "WHERE emp_id = ?";
	        ps = conn.prepareStatement(sql);
	        ps.setDate(1, emp.getDob());
	        ps.setString(2,emp.getGender());
	        ps.setString(3, emp.getPhoneNumber());
	        ps.setDate(4, emp.getDoj());
	        ps.setString(5, emp.getQualification());
	        ps.setString(6, emp.getExperience());
	        ps.setInt(7, emp.getYoe());
	        ps.setInt(8, managerId);
	        ps.setInt(9, emp.getEmpId());   
//	        
//	        ps.setDate(1, dob);
//	        ps.setString(2,gender);
//	        ps.setString(3, phno);
//	        ps.setDate(4, doj);
//	        ps.setString(5, qualification);
//	        ps.setString(6, experience);
//	        ps.setInt(7, yoe);
//	        ps.setInt(8, managerId);
//	        ps.setInt(9, editEmpId); 
	        
	        int result = ps.executeUpdate();

	        if (result > 0) {
	            // Update successful, remove editEmployee from session
	        	response.getWriter().append("Updated successfully");
	            session = request.getSession();
	            session.removeAttribute("editEmployee");
	            //response.getWriter().append("Updated successfully");
	            //response.sendRedirect("others.jsp"); // Reload the page
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    
		
	}

	private void loadEmployee(int empId, HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String empName = "";
        String email = "";
        String phoneNumber = "";
        String qualification = "";
        String experience = "";
        String gender = "";
        int yoe = 0;
        Date dob = null;
        Date doj = null;
		try {
	        ps = conn.prepareStatement("SELECT * FROM Employee WHERE emp_id = ?");
	        ps.setInt(1, empId);
	        rs = ps.executeQuery();

	        if (rs.next()) {
	        	empName = rs.getString("emp_name");
                email = rs.getString("email");
                phoneNumber = rs.getString("phone_number");
                qualification = rs.getString("qualification");
                experience = rs.getString("experience");
                gender = rs.getString("gender");
                dob = rs.getDate("DOB");
                doj = rs.getDate("DOJ");
                yoe = rs.getInt("year_of_experience");

	            Employee emp = new Employee(empId, empName, email);
	            emp.setPhoneNumber(phoneNumber);
	            emp.setQualification(qualification);
	            emp.setExperience(experience);
	            emp.setGender(gender);
	            emp.setDob(dob);
	            emp.setDoj(doj);
	            emp.setYoe(yoe);
	            

	            // Set editEmployee in session
	            session = request.getSession();
	            session.setAttribute("editEmployee", emp);
	        }

	        // Redirect with input_type parameter to display the form
	        response.sendRedirect("others.jsp?input_type=edit_employee"); 

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		
	}

	private void viewEmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		try {
			ps = conn.prepareStatement("SELECT emp_id, emp_name, email from Employee where manager_id = ?");
			ps.setInt(1, sessionId);
			rs = ps.executeQuery();
			
			//List<Employee> empList = new ArrayList<>();
			
//			while(rs.next()) {
//				int empId = rs.getInt("emp_id");
//				String empName = rs.getString("emp_name");
//				String email = rs.getString("email");
//				
//				Employee emp = new Employee(empId, empName, email);
//				if(!empMap.containsKey(empId)) {
//					empMap.put(empId, emp);
//					empList.add(emp);
//				}
//				//empList.add(emp);	
//			}
			
			List<Employee> empList = Others.viewEmployee(managerId, designation);
			System.out.println(managerId+" "+designation);
			
			session.setAttribute("empList" ,empList);
	        Gson gson = new Gson();
	        String jsonResponse = gson.toJson(empList);


	        response.setContentType("application/json");
	        response.setCharacterEncoding("UTF-8");
	        response.getWriter().write(jsonResponse);
			//response.sendRedirect("others.jsp");
		} catch(Exception e) {
			System.out.println("View Employee error :"+e.getMessage());
		}
		
	}

}
