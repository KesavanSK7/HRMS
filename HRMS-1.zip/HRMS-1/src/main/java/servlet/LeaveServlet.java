package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;
import java.sql.Date;
import java.util.*;
import javafile.Leave;
import javafile.DBConnection;
import com.google.gson.Gson;


/**
 * Servlet implementation class LeaveServlet
 */
@WebServlet("/leave/*")
public class LeaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public LeaveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	int sessionID = 0;
	String designation = "";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("LeaveServlet");
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		HttpSession session = req.getSession();
		sessionID = (int)session.getAttribute("emp_id");
		designation = (String)session.getAttribute("designation");
		if(designation == null) {
			designation = "";
		}
		
		
		String path = req.getPathInfo();
		System.out.println(req.getPathInfo());
		
		if(path.equals("/applyleave")) {
			applyLeave(req,res);
			//System.out.println("apply leave");
		}
		else if(path.equals("/viewleaves")) {
			viewLeaves(req,res);
			//System.out.println("view leaves");
		}
		else if(path.equals("/setleave")) {
			setLeave(req,res);
			//System.out.println("set leave");
		}
		else if(path.equals("/approveleave")) {
			approveLeave(req,res);
			//System.out.println("approve leave");
		}	
	}

	Connection conn = DBConnection.getConnection();
	PreparedStatement ps = null;
	public void approveLeave(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		List<Leave> leaveList1 = new ArrayList<>();
		try {
			ps = conn.prepareStatement("select l.leave_id as leave_id, e.emp_id as emp_id,e.manager_id as manager_id,l.leave_type as leave_type,l.start_date as start_date, l.end_date as end_date, l.status as status from Employee e inner join Employee e1 on e.manager_id = e1.emp_id\n"
					+ "inner join LeaveRecord l on e.emp_id = l.emp_id  where l.status = 'pending' and e.manager_id = ?");
			ps.setInt(1,sessionID);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
	            // Create a Leave object for each row in the result set
	            Leave leave = new Leave(
	            	rs.getInt("leave_id"),
	                rs.getInt("emp_id"),
	                rs.getInt("manager_id"),
	                rs.getString("leave_type"),
	                rs.getDate("start_date"),
	                rs.getDate("end_date"),
	                rs.getString("status")
	            );

	            // Add the leave object to the list
	            leaveList1.add(leave);
	        }

	        // Store the list in the session
	        HttpSession session = req.getSession();
	        session.setAttribute("leaveList1", leaveList1);

	        // Redirect to leave.jsp to display the leave records
	        res.sendRedirect("../leave.jsp");
		} catch(Exception e) {
			System.out.println("Leave approval error" + e.getMessage());
		}
		
	}

	public void setLeave(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		System.out.println("Entered Leave Servlet");
		int id = Integer.parseInt(req.getParameter("leave_emp_id"));
		String leaveType = req.getParameter("setleavetype");
		int leaveTypeDays = Integer.parseInt(req.getParameter("leavetypedays"));
		int year = Integer.parseInt(req.getParameter("leaveyear"));
		try {
			ps = conn.prepareStatement("insert into LeaveBalance(emp_id,leave_type,leave_type_days,yr) values(?,?,?,?)");
			ps.setInt(1, id);
			ps.setString(2, leaveType);
			ps.setInt(3, leaveTypeDays);
			ps.setInt(4, year);
			boolean r = ps.execute();
			//System.out.println(r);
			if(!r) {
				res.getWriter().append("Set Leave Successful");
				System.out.println("Set Leave Successful");
				res.sendRedirect("../leave.jsp");
			} else {
				System.out.println("Set Leave error");
			}
		} catch(Exception e) {
			System.out.println("SetLeave Servlet Error" + e.getMessage());
		}
	}

	public void viewLeaves(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		//int id = Integer.parseInt(req.getParameter("leave_emp_id"));
	    
	    // List to hold leave records
		String btn = req.getParameter("leave_btn");
	    List<Leave> leaveList = new ArrayList<>();

	    try {
	        conn = DBConnection.getConnection();
	        if(btn.equals("View my employee leaves")) {
	        	ps = conn.prepareStatement("select l.leave_id, e.emp_id, l.leave_type, l.start_date, l.end_date,l.reason, l.status from Employee e "
	        			+ "inner join LeaveRecord l on e.emp_id = l.emp_id "
	        			+ "where e.manager_id = ?");
		        ps.setInt(1, sessionID);
		        ResultSet rs = ps.executeQuery();

		        while (rs.next()) {
		            // Create a Leave object for each row in the result set
		            Leave leave = new Leave(
		            	rs.getInt("leave_id"),
		                rs.getInt("emp_id"),
		                rs.getString("leave_type"),
		                rs.getDate("start_date"),
		                rs.getDate("end_date"),
		                rs.getString("reason"),
		                rs.getString("status")
		            );
		            // Add the leave object to the list
		            leaveList.add(leave);
		        }
	        }
	        else {
	        	ps = conn.prepareStatement("SELECT * FROM LeaveRecord WHERE emp_id = ?");
	        	ps.setInt(1, sessionID);
	        	ResultSet rs = ps.executeQuery();

	        	while (rs.next()) {
	        		// Create a Leave object for each row in the result set
	        		Leave leave = new Leave(
	        				rs.getInt("leave_id"),
	        				rs.getInt("emp_id"),
	        				rs.getString("leave_type"),
	        				rs.getDate("start_date"),
	        				rs.getDate("end_date"),
	        				rs.getString("reason"),
	        				rs.getString("status")
	        		);
	            // Add the leave object to the list
	            leaveList.add(leave);
	        }
	        }

	        // Store the list in the session
	        HttpSession session = req.getSession();
	        session.setAttribute("leaveList", leaveList);
	        Gson gson = new Gson();
	        String jsonResponse = gson.toJson(leaveList);


	        res.setContentType("application/json");
	        res.setCharacterEncoding("UTF-8");
	        res.getWriter().write(jsonResponse);

	        // Redirect to leave.jsp to display the leave records
	        //res.sendRedirect("../leave.jsp");

	    } catch (Exception e) {
	        System.out.println("Error fetching leave records: " + e.getMessage());
	    }
		
	}

	public void applyLeave(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		int id = sessionID;
		String leaveType = req.getParameter("leavetype");
		Date startDate = Date.valueOf(req.getParameter("startdate"));
		Date endDate = Date.valueOf(req.getParameter("enddate"));
		String reason = req.getParameter("reason");
		
		HttpSession session = req.getSession();
		String lop = (String)session.getAttribute("LOP");
		
		if(lop!=null && lop.equals("LOP")) {
			leaveType = "LOP";
			System.out.println(leaveType);
		}
		try {
			conn = DBConnection.getConnection();
			ps = conn.prepareStatement("insert into LeaveRecord(emp_id, leave_type, start_date, end_date, reason, status) values(?,?,?,?,?,?)");
			ps.setInt(1,id);
			ps.setString(2, leaveType);
			ps.setDate(3, startDate);
			ps.setDate(4, endDate);
			ps.setString(5, reason);
			ps.setString(6, "pending");
			
			int r = ps.executeUpdate();
			if(r>0) {
				System.out.println("Leave Record inserted successfully");
				res.getWriter().append("Leave Record inserted successfully");
				//res.sendRedirect("../leave.jsp");
			}
		} catch(Exception e) {
			System.out.println("LeaveRecord error"+e.getMessage());
		}
		
	}

}
