package servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;

import javax.json.*;
import javax.json.stream.JsonParsingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javafile.DBConnection;
import javafile.Employee;

import java.sql.*;

/**
 * Servlet implementation class UpdateProfileServlet
 */
@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public UpdateProfileServlet() {
        super();
    }
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		
		PrintWriter out = response.getWriter();
		
        int empId = Integer.parseInt(request.getParameter("emp_id"));
        Connection conn = null;
        Employee emp = null;
        try {
            conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Employee WHERE emp_id = ?");
            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new Employee(
                    rs.getInt("emp_id"),
                    rs.getString("emp_name"),
                    rs.getString("email")
                );
                emp.setPhoneNumber(rs.getString("phone_number"));
                emp.setQualification(rs.getString("qualification"));
                emp.setExperience(rs.getString("experience"));
                emp.setGender(rs.getString("gender"));
                emp.setDob(rs.getDate("DOB"));
                emp.setDoj(rs.getDate("DOJ"));
                emp.setYoe(rs.getInt("year_of_experience"));

                // Set employee object in request
                request.setAttribute("employee", emp);
            }

            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        String gender = emp.getGender()==null?"":emp.getGender();
        String experience = emp.getExperience()==null?"":emp.getExperience();
        String phoneNumber = emp.getPhoneNumber()==null?"":emp.getPhoneNumber();
        String qualification = emp.getQualification()==null?"":emp.getQualification();
        int yoe = emp.getYoe()==0?0:emp.getYoe();
        Date dob = emp.getDob();
//        String dob1 = "";
//		if (dob != null)
//			dob1 = "";
		Date doj = emp.getDoj();
//        String doj1 = "";
//		if (doj != null)
//			doj1 = "";
        
        JsonObject responseJson = Json.createObjectBuilder()
        		.add("email", emp.getEmail())
        		.add("emp_name",emp.getEmpName())
        		.add("gender",gender)
        		.add("experience",experience)
        		.add("phone_number",phoneNumber)
        		.add("qualification",qualification)
        		.add("yoe",yoe)
        		.add("DOB", String.valueOf(dob))
        		.add("DOJ", String.valueOf(doj))
                .build();

        // Write response JSON
        out.print(responseJson.toString());
        // Forward the request to the JSP
        //request.getRequestDispatcher("updateProfile.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		HttpSession session = request.getSession();
		int empId = Integer.parseInt(request.getParameter("emp_id"));
		int modifier_id = empId;
        String empName = request.getParameter("emp_name");
        Date dob = Date.valueOf(request.getParameter("DOB"));
        String gender = request.getParameter("gender");
        String phoneNumber = request.getParameter("phone_number");
        String email = request.getParameter("email");
        Date doj = Date.valueOf(request.getParameter("DOJ"));
        String qualification = request.getParameter("qualification");
        String experience = request.getParameter("experience");
        String yoe = request.getParameter("year_of_experience").equals("")?"0":request.getParameter("year_of_experience");
        int yearOfExperience = Integer.parseInt(yoe);
        
        Connection conn = DBConnection.getConnection();
        try {
            String sql = "UPDATE Employee SET emp_name = ?, DOB = ?, gender = ?, phone_number = ?, email = ?, DOJ = ?, qualification = ?, experience = ?, year_of_experience = ?, modified_by = ? WHERE emp_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, empName);
            ps.setDate(2, dob);
            ps.setString(3, gender);
            ps.setString(4, phoneNumber);
            ps.setString(5, email);
            ps.setDate(6, doj);
            ps.setString(7, qualification);
            ps.setString(8, experience);
            ps.setInt(9, yearOfExperience);
            ps.setInt(10, empId);
            ps.setInt(11, empId);
            ps.executeUpdate();
            response.getWriter().append("Updated successfully");
            //response.sendRedirect("home.jsp"); // Redirect to home page or appropriate page
        } catch (Exception e) {
            e.printStackTrace();
           
        }
	}
	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();

        // Read the raw request body
        BufferedReader reader = request.getReader();
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        String requestBody = sb.toString();
        System.out.println("Request Body: " + requestBody);
        
        // Parse JSON request body
        JsonReader jsonReader = Json.createReader(new StringReader(requestBody));
        JsonObject jsonObject = jsonReader.readObject();
        
        int empId = jsonObject.getInt("emp_id");
        String empName = jsonObject.getString("emp_name");
        String email = jsonObject.getString("email");
        String gender = jsonObject.getString("gender");
        String phoneNumber = jsonObject.getString("phone_number");
        String qualification = jsonObject.getString("qualification");
        String experience = jsonObject.getString("experience");
        int yearOfExperience = jsonObject.getInt("year_of_experience");
        java.sql.Date dob = java.sql.Date.valueOf(jsonObject.getString("DOB"));
        java.sql.Date doj = java.sql.Date.valueOf(jsonObject.getString("DOJ"));
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE Employee SET emp_name = ?, DOB = ?, gender = ?, phone_number = ?, email = ?, DOJ = ?, qualification = ?, experience = ?, year_of_experience = ?, modified_by = ? WHERE emp_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, empName);
            ps.setDate(2, dob);
            ps.setString(3, gender);
            ps.setString(4, phoneNumber);
            ps.setString(5, email);
            ps.setDate(6, doj);
            ps.setString(7, qualification);
            ps.setString(8, experience);
            ps.setInt(9, yearOfExperience);
            ps.setInt(10, empId); // Assuming the modifier ID is the same as empId
            ps.setInt(11, empId);
            int rowsAffected = ps.executeUpdate();
            
            JsonObject responseJson = Json.createObjectBuilder()
                .add("success", rowsAffected > 0)
                .add("message", rowsAffected > 0 ? "Profile updated successfully" : "Update failed")
                .build();
            
            out.print(responseJson.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            JsonObject responseJson = Json.createObjectBuilder()
                .add("success", false)
                .add("message", "An error occurred")
                .build();
            
            out.print(responseJson.toString());
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
