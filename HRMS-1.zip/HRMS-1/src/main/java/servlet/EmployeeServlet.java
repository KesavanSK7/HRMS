package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

@WebServlet("/employee/*")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Employee ID not provided.");
            return;
        }
        
        int empId;
        try {
            empId = Integer.parseInt(pathInfo.substring(1));
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid Employee ID format.");
            return;
        }
        
        JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
        boolean success = false;
        String message = "Employee not found";
        
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrms", "root", "Kesavan@2003")) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Employee WHERE emp_id = ?");
            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                jsonBuilder.add("emp_id", rs.getInt("emp_id"));
                jsonBuilder.add("emp_name", rs.getString("emp_name"));
                jsonBuilder.add("email", rs.getString("email"));
                
                // Handle null values for Date
                jsonBuilder.add("DOB", rs.getDate("DOB") != null ? rs.getDate("DOB").toString() : "");
                jsonBuilder.add("gender", rs.getString("gender") != null ? rs.getString("gender") : "");
                jsonBuilder.add("phone_number", rs.getString("phone_number") != null ? rs.getString("phone_number") : "");
                jsonBuilder.add("qualification", rs.getString("qualification") != null ? rs.getString("qualification") : "");
                jsonBuilder.add("experience", rs.getString("experience") != null ? rs.getString("experience") : "");
                jsonBuilder.add("year_of_experience", rs.getInt("year_of_experience"));
                jsonBuilder.add("DOJ", rs.getDate("DOJ") != null ? rs.getDate("DOJ").toString() : "");
                
                success = true;
                message = "Employee data retrieved successfully";
            }
        } catch (Exception e) {
            e.printStackTrace();
            message = "An error occurred";
        }
        
        jsonBuilder.add("success", success);
        jsonBuilder.add("message", message);
        
        out.print(jsonBuilder.build().toString());
    }
}
