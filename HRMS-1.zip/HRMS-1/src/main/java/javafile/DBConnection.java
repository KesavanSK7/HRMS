package javafile;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

public class DBConnection {
	public static Connection getConnection() {
    	Connection conn = null;
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		System.out.println("Driver Connected");
    		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrms","root","Kesavan@2003");
    		System.out.println("Connection successful");
    	} catch(ClassNotFoundException | SQLException e) {
    		System.out.println("e.getMessage()");
    	}
    	return conn;
    }
	public static String getDesignation(int empId) throws SQLException {
		Connection conn = DBConnection.getConnection();
		PreparedStatement ps = conn.prepareStatement("select d.designation from Employee e inner join Designation d on e.desig_id = d.desig_id where emp_id=?");
        ps.setInt(1,empId);
        ResultSet rs = ps.executeQuery();
        String designation = "";
        if(rs.next()){
        	designation = rs.getString("designation");
        	System.out.println(designation);
        }
        else{
        	designation = "";
        }
        return designation;
	}
}
