package javafile;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Others {
	public static List<Employee> viewEmployee(int managerId, String designation){
		Connection conn = DBConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Employee> empList = new ArrayList<>();
		try {
			if(designation.equals("Manager")) {
				ps = conn.prepareStatement("SELECT emp_id, emp_name, email from Employee where manager_id = ?");
				ps.setInt(1, managerId);
				rs = ps.executeQuery();
			}
			else {
				ps = conn.prepareStatement("SELECT emp_id, emp_name, email from Employee");
				rs = ps.executeQuery();
			}
			
			
			while(rs.next()) {
				int empId = rs.getInt("emp_id");
				String empName = rs.getString("emp_name");
				String email = rs.getString("email");
				
				Employee emp = new Employee(empId, empName, email);
				empList.add(emp);
				
				//empList.add(emp);	
			}
			
		} catch(Exception e) {
			System.out.println("View Employee error :"+e.getMessage());
		}
		return empList;
		
	}
}
