package javafile;
import java.sql.*;

public class Leave {
	private int leaveId;
    private int empId;
    private int managerId;
    private String leaveType;
    private Date startDate;
    private Date endDate;
    private String reason;
    private String status;

    // Constructor
    public Leave(int leaveId,int empId, String leaveType, Date startDate, Date endDate, String reason, String status) {
        this.leaveId = leaveId;
    	this.empId = empId;
        this.leaveType = leaveType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
        this.status = status;
    }

    public Leave(int leaveId, int int1, int int2, String leaveType, Date startDate, Date endDate, String status) {
		// TODO Auto-generated constructor stub
    	this.leaveId = leaveId;
    	this.empId = int1;
    	this.managerId = int2;
    	this.leaveType = leaveType;
    	this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
	}

	// Getters and Setters
    
    public int getLeaveId() {
        return leaveId;
    }

    public void setLeaveId(int leaveId) {
        this.leaveId = leaveId;
    }
    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
}

