

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import org.json.JSONObject;

/**
 * Servlet implementation class SalaryServlet
 */
@WebServlet("/salary")
public class SalaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public SalaryServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String type = request.getParameter("type");
		
		Connection conn = null;
		JSONObject responseJson = new JSONObject();
		if(type.equals("calculate")) {
		String empEmail = request.getParameter("emp_email");
		int month = Integer.parseInt(request.getParameter("month"));
		int year = Integer.parseInt(request.getParameter("year"));
		
		
		
			try {
				conn = DBConnection.getConnection();
				
				conn.setTransactionIsolation(conn.TRANSACTION_SERIALIZABLE); 
				conn.setAutoCommit(false);
				//lockTable(conn);
				
//				String query1 = "select e.emp_id, lr.leave_type, SUM(DATEDIFF(lr.end_date, lr.start_date)) as _leaves, "
//						+ "MONTH(lr.start_date) as mon from Employee e "
//						+ "inner join LeaveRecord lr on e.emp_id = lr.emp_id "
//						+ "where e.email = ? and lr.status = 'approved' and MONTH(lr.start_date) = ? "
//						+ "group by e.emp_id, lr.leave_type";
				
				
				String query1 = "SELECT Employee.emp_id, LeaveRecord.leave_type, SUM(DATEDIFF(LeaveRecord.end_date, LeaveRecord.start_date)) as _leaves, " +
				                "MONTH(LeaveRecord.start_date) as mon FROM Employee " +
				                "INNER JOIN LeaveRecord ON Employee.emp_id = LeaveRecord.emp_id " +
				                "WHERE Employee.email = ? AND LeaveRecord.status = 'approved' AND MONTH(LeaveRecord.start_date) = ? " +
				                "GROUP BY Employee.emp_id, LeaveRecord.leave_type";

				// Similar changes for other queries where you used aliases like 'e' for 'Employee'

				
				PreparedStatement ps = conn.prepareStatement(query1);
				ps.setString(1,empEmail);
				ps.setInt(2, month);
				
				int lop = 0, workingDays = 0, cl = 0, sl = 0;
				int monthDays = 30;
				boolean isLeapYear = false;
				
				double monthlySalary = 0;
				int empId = 0;
				ResultSet rs = ps.executeQuery();
				while(rs.next()) {
					String leaveType = rs.getString("leave_type");
					int leaves = rs.getInt("_leaves");
					empId = rs.getInt("emp_id");
					if(leaveType.equals("LOP"))
						lop = leaves;
					else if(leaveType.equals("CL"))
						cl = leaves;
					else if(leaveType.equals("SL"))
						sl = leaves;
				}
				
//				String query2 = "select COUNT(DISTINCT a.checkin_date) as working_days, e.emp_id, e.email, status from Attendance a "
//						+ "inner join Employee e on e.emp_id = a.emp_id "
//						+ "where e.email = ? and a.status = 'O' and MONTH(a.checkin_date) = ?";
				
				String query2 = "SELECT COUNT(DISTINCT Attendance.checkin_date) AS working_days, Employee.emp_id, Employee.email, Attendance.status "
			              + "FROM Attendance "
			              + "INNER JOIN Employee ON Employee.emp_id = Attendance.emp_id "
			              + "WHERE Employee.email = ? AND Attendance.status = 'O' AND MONTH(Attendance.checkin_date) = ?";

				
				ps = conn.prepareStatement(query2);
				ps.setString(1, empEmail);
				ps.setInt(2, month);
				rs = ps.executeQuery();
				
				if(rs.next()) {
					workingDays = rs.getInt("working_days");
				}
				
//				String query3 = "select e.emp_id, e.email, s.monthly_salary from Employee e "
//						+ "inner join Salary s on e.emp_id = s.emp_id "
//						+ "where e.email = ?";
				
				String query3 = "SELECT Employee.emp_id, Employee.email, Salary.monthly_salary "
			              + "FROM Employee "
			              + "INNER JOIN Salary ON Employee.emp_id = Salary.emp_id "
			              + "WHERE Employee.email = ?";

				ps = conn.prepareStatement(query3);
				ps.setString(1, empEmail);
				rs = ps.executeQuery();
				if(rs.next()) {
					monthlySalary = rs.getDouble("monthly_salary");
				}
				
				if(month==2) {
					monthDays = 28; 
					if((year%4==0 && year%100!=0) || (year%400==0)) {
						isLeapYear = true;
						monthDays = 29;
					}
				}
				else if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
					monthDays = 31;
				}
				
				
				int totalWorkingDays = workingDays + cl + sl - lop;
				if(totalWorkingDays < 0) {
					totalWorkingDays = 0;
				}
				double calculatedSalary = (monthlySalary/monthDays)*totalWorkingDays;
				String strcalculatedSalary = String.format("%.2f", calculatedSalary);
				calculatedSalary = Double.parseDouble(strcalculatedSalary);
				
				responseJson.put("status", "success");
				responseJson.put("WD", workingDays);
				responseJson.put("LOP", lop);
				responseJson.put("CL", cl);
				responseJson.put("SL", sl);
				responseJson.put("totalWorkingDays", totalWorkingDays);
				responseJson.put("monthlySalary",monthlySalary);
				responseJson.put("monthDays", monthDays);
				responseJson.put("calculatedSalary", calculatedSalary);
				
				responseJson.put("message", "Calculated salary");
				
				Thread.sleep(10000);
				//unlockTable(conn);
		        conn.commit();
				
			} 
			catch(Exception e) {
				responseJson.put("status","error");
				responseJson.put("message", "Error calculating salary :"+e.getMessage());
			}
		}
		response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseJson.toString());
        
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		StringBuilder sb = new StringBuilder();
		BufferedReader reader = request.getReader();
		String line;
		while((line = reader.readLine()) !=null) {
			sb.append(line);
		}
		
		JSONObject jsonObj = new JSONObject(sb.toString());
//		String empEmail = jsonObj.getString("emp_email");
//		double monthlySalary = jsonObj.getDouble("monthly_salary");
		String type = jsonObj.getString("type");
		
		JSONObject responseJson = new JSONObject();
		
		Connection conn = null;
		
		if(type.equals("new_entry")) {
			String empEmail = jsonObj.getString("emp_email");
			double monthlySalary = jsonObj.getDouble("monthly_salary");
			try {
				int empId = 0;
				conn = DBConnection.getConnection();
				String query1 = "select emp_id from Employee where email = ?";
				String query2 = "insert into Salary(emp_id, monthly_salary) values(?,?)";
				PreparedStatement ps = conn.prepareStatement(query1);
				ps.setString(1,empEmail);
				ResultSet rs = ps.executeQuery();
				if(rs.next()) {
					empId = rs.getInt("emp_id");
					ps = conn.prepareStatement(query2);
					ps.setInt(1, empId);
					ps.setDouble(2, monthlySalary);
					int r = ps.executeUpdate();
					if(r>0) {
						responseJson.put("status","success");
						responseJson.put("message", "Salary has been set successfully");
					} else {
						responseJson.put("status","failure");
						responseJson.put("message", "Failed to set salary");
					}
				} else {
					responseJson.put("status","failure");
					responseJson.put("message", "Employee not exists");
				}
			} catch(Exception e) {
				responseJson.put("status","error");
				responseJson.put("message", "Error creating department :"+e.getMessage());
			}
		}
		else if(type.equals("calculate")) {
			String empEmail = jsonObj.getString("emp_email");
			int month = jsonObj.getInt("month");
			int year = jsonObj.getInt("year");
			
			try {
				conn = DBConnection.getConnection();
				
				conn.setTransactionIsolation(conn.TRANSACTION_SERIALIZABLE); 
				conn.setAutoCommit(false);
				//lockTable(conn);
				
//				String query1 = "select e.emp_id, lr.leave_type, SUM(DATEDIFF(lr.end_date, lr.start_date)) as _leaves, "
//						+ "MONTH(lr.start_date) as mon from Employee e "
//						+ "inner join LeaveRecord lr on e.emp_id = lr.emp_id "
//						+ "where e.email = ? and lr.status = 'approved' and MONTH(lr.start_date) = ? "
//						+ "group by e.emp_id, lr.leave_type";
				
				
				String query1 = "SELECT Employee.emp_id, LeaveRecord.leave_type, SUM(DATEDIFF(LeaveRecord.end_date, LeaveRecord.start_date)) as _leaves, " +
				                "MONTH(LeaveRecord.start_date) as mon FROM Employee " +
				                "INNER JOIN LeaveRecord ON Employee.emp_id = LeaveRecord.emp_id " +
				                "WHERE Employee.email = ? AND LeaveRecord.status = 'approved' AND MONTH(LeaveRecord.start_date) = ? " +
				                "GROUP BY Employee.emp_id, LeaveRecord.leave_type";

				// Similar changes for other queries where you used aliases like 'e' for 'Employee'

				
				PreparedStatement ps = conn.prepareStatement(query1);
				ps.setString(1,empEmail);
				ps.setInt(2, month);
				
				int lop = 0, workingDays = 0, cl = 0, sl = 0;
				int monthDays = 30;
				boolean isLeapYear = false;
				
				double monthlySalary = 0;
				int empId = 0;
				ResultSet rs = ps.executeQuery();
				while(rs.next()) {
					String leaveType = rs.getString("leave_type");
					int leaves = rs.getInt("_leaves");
					empId = rs.getInt("emp_id");
					if(leaveType.equals("LOP"))
						lop = leaves;
					else if(leaveType.equals("CL"))
						cl = leaves;
					else if(leaveType.equals("SL"))
						sl = leaves;
				}
				
//				String query2 = "select COUNT(DISTINCT a.checkin_date) as working_days, e.emp_id, e.email, status from Attendance a "
//						+ "inner join Employee e on e.emp_id = a.emp_id "
//						+ "where e.email = ? and a.status = 'O' and MONTH(a.checkin_date) = ?";
				
				String query2 = "SELECT COUNT(DISTINCT Attendance.checkin_date) AS working_days, Employee.emp_id, Employee.email, Attendance.status "
			              + "FROM Attendance "
			              + "INNER JOIN Employee ON Employee.emp_id = Attendance.emp_id "
			              + "WHERE Employee.email = ? AND Attendance.status = 'O' AND MONTH(Attendance.checkin_date) = ?";

				
				ps = conn.prepareStatement(query2);
				ps.setString(1, empEmail);
				ps.setInt(2, month);
				rs = ps.executeQuery();
				
				if(rs.next()) {
					workingDays = rs.getInt("working_days");
				}
				
//				String query3 = "select e.emp_id, e.email, s.monthly_salary from Employee e "
//						+ "inner join Salary s on e.emp_id = s.emp_id "
//						+ "where e.email = ?";
				
				String query3 = "SELECT Employee.emp_id, Employee.email, Salary.monthly_salary "
			              + "FROM Employee "
			              + "INNER JOIN Salary ON Employee.emp_id = Salary.emp_id "
			              + "WHERE Employee.email = ?";

				ps = conn.prepareStatement(query3);
				ps.setString(1, empEmail);
				rs = ps.executeQuery();
				if(rs.next()) {
					monthlySalary = rs.getDouble("monthly_salary");
				}
				
				if(month==2) {
					monthDays = 28; 
					if((year%4==0 && year%100!=0) || (year%400==0)) {
						isLeapYear = true;
						monthDays = 29;
					}
				}
				else if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
					monthDays = 31;
				}
				
				
				int totalWorkingDays = workingDays + cl + sl - lop;
				if(totalWorkingDays < 0) {
					totalWorkingDays = 0;
				}
				double calculatedSalary = (monthlySalary/monthDays)*totalWorkingDays;
				String strcalculatedSalary = String.format("%.2f", calculatedSalary);
				calculatedSalary = Double.parseDouble(strcalculatedSalary);
				
				responseJson.put("status", "success");
				responseJson.put("WD", workingDays);
				responseJson.put("LOP", lop);
				responseJson.put("CL", cl);
				responseJson.put("SL", sl);
				responseJson.put("totalWorkingDays", totalWorkingDays);
				responseJson.put("monthlySalary",monthlySalary);
				responseJson.put("monthDays", monthDays);
				responseJson.put("calculatedSalary", calculatedSalary);
				
				responseJson.put("message", "Calculated salary");
				
				Thread.sleep(10000);
				//unlockTable(conn);
		        conn.commit();
				
			} 
			catch(Exception e) {
				responseJson.put("status","error");
				responseJson.put("message", "Error calculating salary :"+e.getMessage());
			}
		}
		response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseJson.toString());
        
//        try {
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	}

	private void lockTable(Connection conn) throws SQLException{
		String lockQuery = "LOCK TABLES LeaveRecord WRITE, Employee WRITE, Attendance WRITE, Salary WRITE";
		try (PreparedStatement ps = conn.prepareStatement(lockQuery)) {
            ps.execute();
        }	
	}

	private void unlockTable(Connection conn) throws SQLException{
		String unlockQuery = "UNLOCK TABLES";
		try (PreparedStatement ps = conn.prepareStatement(unlockQuery)) {
            ps.execute();
        }
	}

}
