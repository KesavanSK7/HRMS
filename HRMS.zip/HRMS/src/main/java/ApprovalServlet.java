

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;

/**
 * Servlet implementation class ApprovalServlet
 */
@WebServlet("/approval")
public class ApprovalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApprovalServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String action = request.getParameter("action");
        int leaveId = Integer.parseInt(request.getParameter("leaveId"));
        int empId = Integer.parseInt(request.getParameter("empId"));
        

        	try (Connection conn = DBConnection.getConnection()) {
        		
        		conn.setTransactionIsolation(conn.TRANSACTION_SERIALIZABLE);
        		conn.setAutoCommit(false);
        		
        		String status = "rejected";
        		if ("Approve".equals(action)) {
        			status = "approved";
        		}else if("Cancel".equals(action)) {
        			status = "Cancelled"; 
        		}
        		
        		//lockTable(conn);
            
        		String updateSQL = "UPDATE LeaveRecord SET status = ? WHERE leave_id = ? AND emp_id = ?";
        		try  (PreparedStatement ps = conn.prepareStatement(updateSQL)){
        			ps.setString(1, status);
        			ps.setInt(2, leaveId);
        			ps.setInt(3, empId);
        			int r = ps.executeUpdate();
        			if(r>0) {
        				System.out.println("Leave record updated "+status);
        			}
        			
        			Thread.sleep(10000);
        			conn.commit();
        			//unlockTable(conn);
        		}

        		HttpSession session = request.getSession();
        		session.setAttribute("leaveUpdateMessage", "Leave request has been " + status + ".");

        		response.sendRedirect("leave.jsp");
        	} catch (Exception e) {
        		e.printStackTrace();
        		request.setAttribute("errorMessage", "Error updating leave status.");
        		request.getRequestDispatcher("leave.jsp").forward(request, response);
        	}

	}
	
	private void lockTable(Connection conn) throws SQLException{
		String lockQuery = "LOCK TABLES LeaveRecord WRITE, Employee WRITE, Attendance WRITE, Salary WRITE";
		try (PreparedStatement ps = conn.prepareStatement(lockQuery)) {
            ps.execute();
        }	
	}

	private void unlockTable(Connection conn) throws SQLException{
		String unlockQuery = "UNLOCK TABLES";
		try (PreparedStatement ps = conn.prepareStatement(unlockQuery)) {
            ps.execute();
        }
	}

}
