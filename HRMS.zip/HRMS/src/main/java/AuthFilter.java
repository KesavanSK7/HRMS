

import java.io.IOException;
import java.sql.*;
import java.sql.DriverManager;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class AuthFilter
 */
@WebFilter("/signup")
public class AuthFilter extends HttpFilter implements Filter {

    public AuthFilter() {
        super();
    }

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		HttpSession session = req.getSession();
		
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver connected");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrms","root","Kesavan@2003");
			System.out.println("Connection successful");
		} catch(ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		}
		
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		String emp_name = request.getParameter("username");
		try {
			PreparedStatement ps = conn.prepareStatement("select * from Employee where email = ?");
			ps.setString(1,email);
		
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("User already exists");
				session.setAttribute("userError", "User already exists");
				res.sendRedirect("index.jsp");
			}
			else {
				System.out.println("New user");
				PreparedStatement ps1 = conn.prepareStatement("insert into Employee(email,pass,emp_name) values(?,?,?)");
				ps1.setString(1, email);
				ps1.setString(2, pass);
				ps1.setString(3, emp_name);
				int r = ps1.executeUpdate();
				if(r>0) {
					System.out.println("Inserted successfully");
					res.sendRedirect("index.html");
				}
				else {
					System.out.println("Insertion error");
				}
				//chain.doFilter(request, response);
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
