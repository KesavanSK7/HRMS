

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import java.sql.*;

/**
 * Servlet implementation class AssignDeptServlet
 */
@WebServlet("/assigndept")
public class AssignDeptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public AssignDeptServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Parse JSON data from request body
	    StringBuilder sb = new StringBuilder();
	    BufferedReader reader = request.getReader();
	    String line;
	    while ((line = reader.readLine()) != null) {
	        sb.append(line);
	    }
	    
	    // Convert the JSON string to a JSON object
	    JSONObject jsonObj = new JSONObject(sb.toString());
	    
	    String empEmail = jsonObj.getString("emp_email");
	    String deptName = jsonObj.getString("dept_name");
		Connection conn = DBConnection.getConnection();
		PreparedStatement ps = null;
		
		JSONObject responseJson = new JSONObject();
		try {
			String assignDeptQuery = "Update Employee set dept_id = "
					+ "(select dept_id from Department where dept_name = ?) "
					+ "where email = ?;";
			ps = conn.prepareStatement(assignDeptQuery);
			ps.setString(1, deptName);
			ps.setString(2, empEmail);
			int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                // Success response
                responseJson.put("status", "success");
                responseJson.put("message", "Department assigned successfully");
            } else {
                // Failure response (if no rows are updated)
                responseJson.put("status", "failure");
                responseJson.put("message", "Failed to assign department");
            }
        } catch (Exception e) {
            // Error response
            responseJson.put("status", "error");
            responseJson.put("message", "Error assigning department: " + e.getMessage());
        }
		
		response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseJson.toString());
	}

}
