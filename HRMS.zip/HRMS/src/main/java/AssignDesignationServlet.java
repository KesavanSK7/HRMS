

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import java.sql.*;

/**
 * Servlet implementation class AssignDesignationServlet
 */
@WebServlet("/assigndesig")
public class AssignDesignationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AssignDesignationServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
//	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//	    // Set the content type to application/json
//	    response.setContentType("application/json");
//	    response.setCharacterEncoding("UTF-8");
//
//	    // Initialize the JSON response object
//	    JSONObject responseJson = new JSONObject();
//
//	    // Read the request body (JSON input) - this can only be done once
//	    StringBuilder sb = new StringBuilder();
//	    String line;
//	    BufferedReader reader = request.getReader();
//	    System.out.println(reader);
//	        while ((line = reader.readLine()) != null) {
//	            sb.append(line);
//	        }
//
//	    // Parse the input JSON string
//	    String jsonInput = sb.toString();
//	    JSONObject inputJson;
//	    try {
//	        inputJson = new JSONObject(jsonInput);
//	    } catch (Exception e) {
//	        responseJson.put("status", "error");
//	        responseJson.put("message", "Invalid JSON input: " + e.getMessage());
//	        response.getWriter().write(responseJson.toString());
//	        return; // Exit early on error
//	    }
//
//	    // Extract data from JSON object
//	    String email;
//	    int desig_id;
//	    try {
//	        email = inputJson.getString("email");
//	        desig_id = inputJson.getInt("desig");
//	    } catch (Exception e) {
//	        responseJson.put("status", "error");
//	        responseJson.put("message", "Missing or invalid fields: " + e.getMessage());
//	        response.getWriter().write(responseJson.toString());
//	        return; // Exit early on error
//	    }
//
//	    // Database interaction
//	    Connection conn = null;
//	    try {
//	        conn = DBConnection.getConnection();
//
//	        // Prepare and execute the SQL update query
//	        PreparedStatement ps1 = conn.prepareStatement("UPDATE Employee SET desig_id = ? WHERE email = ?");
//	        ps1.setInt(1, desig_id);
//	        ps1.setString(2, email);
//	        int rowsUpdated = ps1.executeUpdate();
//
//	        // Create the response based on the update result
//	        if (rowsUpdated > 0) {
//	            System.out.println("Assigned Designation successfully");
//	            responseJson.put("status", "success");
//	            responseJson.put("message", "Designation assigned successfully");
//	        } else {
//	            responseJson.put("status", "failure");
//	            responseJson.put("message", "Failed to assign designation. Employee not found.");
//	        }
//
//	    } catch (Exception e) {
//	        System.out.println("Error: " + e.getMessage());
//	        responseJson.put("status", "error");
//	        responseJson.put("message", "Error occurred: " + e.getMessage());
//	    } finally {
//	        // Ensure connection is closed
//	        if (conn != null) {
//	            try {
//	                conn.close();
//	            } catch (SQLException e) {
//	                e.printStackTrace();
//	            }
//	        }
//	    }
//
//	    // Send the JSON response back to the client
//	    response.getWriter().write(responseJson.toString());
//	}

	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");

	    JSONObject responseJson = new JSONObject();

	    String email = (String) request.getAttribute("email");
	    int desig_id = (Integer) request.getAttribute("desig_id");

	    if (email == null || desig_id == 0) {
	        responseJson.put("status", "error");
	        responseJson.put("message", "Missing email or designation.");
	        response.getWriter().write(responseJson.toString());
	        return;
	    }

	    Connection conn = null;
	    try {
	        conn = DBConnection.getConnection();

	        PreparedStatement ps1 = conn.prepareStatement("UPDATE Employee SET desig_id = ? WHERE email = ?");
	        ps1.setInt(1, desig_id);
	        ps1.setString(2, email);
	        int rowsUpdated = ps1.executeUpdate();

	        if (rowsUpdated > 0) {
	            System.out.println("Assigned Designation successfully");
	            responseJson.put("status", "success");
	            responseJson.put("message", "Designation assigned successfully");
	        } else {
	            responseJson.put("status", "failure");
	            responseJson.put("message", "Failed to assign designation. Employee not found.");
	        }

	    } catch (Exception e) {
	        System.out.println("Error: " + e.getMessage());
	        responseJson.put("status", "error");
	        responseJson.put("message", "Error occurred: " + e.getMessage());
	    } finally {
	        if (conn != null) {
	            try {
	                conn.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	    response.getWriter().write(responseJson.toString());
	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		String email = request.getParameter("email");
		int desig_id = Integer.parseInt(request.getParameter("desig"));
		
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps1 = conn.prepareStatement("update Employee set desig_id = ? where email = ?");
			ps1.setInt(1, desig_id);
			ps1.setString(2,email);
			int r = ps1.executeUpdate();
			if(r>0) {
				System.out.println("Assigned Designation successfully");
				response.sendRedirect("settings.jsp");
			}
			else {
				System.out.println("Assigning Designation error");
			}
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
