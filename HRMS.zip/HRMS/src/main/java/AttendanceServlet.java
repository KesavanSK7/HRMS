import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import abc.Attendance;

@WebServlet("/attendance")
public class AttendanceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    Connection conn = DBConnection.getConnection();
    PreparedStatement ps = null;
    int sessionId = 0;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String dateStr = (String) session.getAttribute("currDate"); // Get the date as String
        String status = request.getParameter("att-btn");
        Date date = null;

        if (dateStr != null) {
            date = Date.valueOf(dateStr); // Convert String to java.sql.Date
        }

        int empId = (int) session.getAttribute("emp_id");
        sessionId = empId;

        if ("Checkin".equalsIgnoreCase(status)) {
            handleCheckin(session, response, empId, date);
        } else if ("Checkout".equalsIgnoreCase(status)) {
            handleCheckout(session, response, empId);
        }
    }

    private void handleCheckin(HttpSession session, HttpServletResponse response, int empId, Date date) throws IOException {
        try {
//            ps = conn.prepareStatement("SELECT attendance_id FROM Attendance WHERE emp_id = ? AND checkin_date = CURDATE()");
//            ps.setInt(1, empId);
//            ResultSet rs = ps.executeQuery();
//
//            if (rs.next()) {
//                // Already checked in for today
//                System.out.println("Already checked in for today.");
//            } else {
                // Insert a new attendance record for today
                ps = conn.prepareStatement("INSERT INTO Attendance (emp_id, checkin_date, checkin_time, status) VALUES (?, CURDATE(), CURTIME(), 'P')");
                ps.setInt(1, empId);
                ps.executeUpdate();
                System.out.println("Attendance inserted successfully");
                session.setAttribute("att_status", "P");
//            }

            response.sendRedirect("attendance.jsp");
        } catch (SQLException e) {
            System.out.println("Error during check-in: " + e.getMessage());
        }
    }

    private void handleCheckout(HttpSession session, HttpServletResponse response, int empId) throws IOException {
        try {
            ps = conn.prepareStatement("SELECT attendance_id FROM Attendance WHERE emp_id = ? AND checkout_time IS NULL");
            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int attendanceId = rs.getInt("attendance_id");
                ps = conn.prepareStatement("UPDATE Attendance SET checkout_date = CURDATE(), checkout_time = CURTIME(), status = 'O' WHERE attendance_id = ?");
                ps.setInt(1, attendanceId);
                int r = ps.executeUpdate();
                if (r > 0) {
                    System.out.println("Checked out successfully");
                    session.setAttribute("att_status", "O");
                }
            } else {
                System.out.println("No check-in record found for today.");
            }

            response.sendRedirect("attendance.jsp");
        } catch (SQLException e) {
            System.out.println("Check-out failure: " + e.getMessage());
        }
    }

}
