
import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import abc.Report;

@WebServlet("/report")
public class ReportServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ReportServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        int managerId = (int) session.getAttribute("emp_id");
        String reportType = request.getParameter("reportType");
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        if ("monthly".equals(reportType)) {
            
            Map<Integer, Report> reportMap = new HashMap<>();

            try {
                // Query for getting CL and SL
                String leaveBalQuery = "SELECT e.emp_id, e.emp_name, lb.leave_type, SUM(lb.leave_type_days) AS total_available_days "
                		+ "FROM Employee e "
                		+ "INNER JOIN LeaveBalance lb ON e.emp_id = lb.emp_id "
                		+ "WHERE lb.leave_type IN ('CL', 'SL') AND e.manager_id = ? "
                		+ "GROUP BY e.emp_id, e.emp_name, lb.leave_type";
                ps = conn.prepareStatement(leaveBalQuery);
                ps.setInt(1, managerId);
                rs = ps.executeQuery();
                
                while(rs.next()) {
                	int empId = rs.getInt("emp_id");
                    String empName = rs.getString("emp_name");
                    String leaveType = rs.getString("leave_type");
                    int totAvailDays = rs.getInt("total_available_days");
                    
                    Report report = reportMap.getOrDefault(empId, new Report(empId, empName));
                    if(leaveType.equals("CL"))
                    	report.setCL(totAvailDays);
                    else if(leaveType.equals("SL"))
                    	report.setSL(totAvailDays);
                    reportMap.put(empId, report);
                }
                
                //Query for getting LeaveRecord leaves used
                String leaveRecQuery = "SELECT e.emp_id, e.emp_name, lr.leave_type,"
                		+ "SUM(DATEDIFF(lr.end_date, lr.start_date)) AS total_used_days "
                		+ "FROM Employee e inner join LeaveRecord lr on e.emp_id = lr.emp_id "
                		+ "where lr.leave_type in ('CL','SL') and e.manager_id = ? "
                		+ "GROUP BY e.emp_id, e.emp_name, lr.leave_type";
                ps = conn.prepareStatement(leaveRecQuery);
                ps.setInt(1, managerId);
                rs = ps.executeQuery();
                
                while(rs.next()) {
                	int empId = rs.getInt("emp_id");
                    String empName = rs.getString("emp_name");
                    String leaveType = rs.getString("leave_type");
                    int totUsedDays = rs.getInt("total_used_days");
                    
                    Report report = reportMap.getOrDefault(empId, new Report(empId, empName));
                    if(leaveType.equals("CL"))
                    	report.setClu(totUsedDays);
                    else if(leaveType.equals("SL"))
                    	report.setSlu(totUsedDays);
                    reportMap.put(empId, report);
                }
                
                
                // Query for Working Days
                String workingDaysSQL = "SELECT e.emp_id, e.emp_name, MONTH(a.checkin_date) AS month, " +
                                        "COUNT(DISTINCT a.checkin_date) AS working_days " +
                                        "FROM Employee e JOIN Attendance a ON e.emp_id = a.emp_id " +
                                        "WHERE e.manager_id = ? " +
                                        "GROUP BY e.emp_id, e.emp_name, MONTH(a.checkin_date) " +
                                        "ORDER BY e.emp_id, month";
                ps = conn.prepareStatement(workingDaysSQL);
                ps.setInt(1, managerId);
                rs = ps.executeQuery();

                while (rs.next()) {
                    int empId = rs.getInt("emp_id");
                    String empName = rs.getString("emp_name");
                    int month = rs.getInt("month");
                    int workingDays = rs.getInt("working_days");

                    Report report = reportMap.getOrDefault(empId, new Report(empId, empName));
                    report.setWorkingDays(month, workingDays);
                    reportMap.put(empId, report);
                }

                rs.close();
                ps.close();

                // Query for Loss Of Pay Days
                String lopSQL = "SELECT e.emp_id, e.emp_name, MONTH(lr.start_date) AS month, " +
                                "SUM(datediff(lr.end_date,lr.start_date)) AS lop_days " +
                                "FROM Employee e JOIN LeaveRecord lr ON e.emp_id = lr.emp_id " +
                                "WHERE e.manager_id = ? AND lr.leave_type = 'LOP' " +
                                "GROUP BY e.emp_id, e.emp_name, MONTH(lr.start_date) " +
                                "ORDER BY e.emp_id, month";
                ps = conn.prepareStatement(lopSQL);
                ps.setInt(1, managerId);
                rs = ps.executeQuery();

                while (rs.next()) {
                    int empId = rs.getInt("emp_id");
                    int month = rs.getInt("month");
                    int lopDays = rs.getInt("lop_days");

                    Report report = reportMap.get(empId);
                    if (report != null) {
                        report.setLopDays(month, lopDays);
                    }
                }

                session.setAttribute("reportData", reportMap);
                session.setAttribute("reportType", "monthly");

            } catch (SQLException e) {
                e.printStackTrace();
            } 

            response.sendRedirect("report.jsp");
            
        } else if("yearly".equals(reportType)) {
        	try {
        		String userwiseQuery = "select e.emp_id, e.emp_name, sum(datediff(l.end_date, l.start_date)) as no_of_days from Employee e "
        				+"inner join LeaveRecord l on e.emp_id = l.emp_id "
        				+"where e.manager_id = ? and l.status = 'approved' "
        				+"group by e.emp_id, e.emp_name order by no_of_days desc ";
                ps = conn.prepareStatement(userwiseQuery);
                ps.setInt(1, managerId);
                rs = ps.executeQuery();
                
                List<Report> reportList = new ArrayList<>();
                while(rs.next()) {
                	int empId = rs.getInt("emp_id");
                	int noOfDays = rs.getInt("no_of_days");
                	String empName = rs.getString("emp_name");
                	
                	Report report = new Report(empId, empName, noOfDays);
                	reportList.add(report);
                }
                
                session.setAttribute("reportList", reportList);
                session.setAttribute("reportType", "yearly");
                response.sendRedirect("report.jsp");
                
        	} catch (Exception e) {
        		System.out.println("Userwise report error :"+e.getMessage());
        	}
        }
        else if(reportType.equals("dept_yearly")) {
        	String year = request.getParameter("yr");
        	String deptName = request.getParameter("dept_name");
        	
        	Map<Integer, Report> reportMap = new HashMap<>();
        	try {
        		String query = "select e.emp_id, e.emp_name, e.dept_id, SUM(DATEDIFF(lr.end_date, lr.start_date)) as _leaves, MONTH(end_date) as mon "
        				+ "from Employee e inner join Department d on e.dept_id = d.dept_id "
        				+ "left join LeaveRecord lr on e.emp_id = lr.emp_id "
        				+ "where d.dept_name = ? and lr.status = 'approved' "
        				+ "group by e.emp_id, e.emp_name, e.dept_id, mon "
        				+ "order by _leaves desc";
        		ps = conn.prepareStatement(query);
        		ps.setString(1, deptName);
        		rs = ps.executeQuery();
        		//List<Report> reportList = new ArrayList<>();
                while(rs.next()) {
                	int empId = rs.getInt("emp_id");
                	String empName = rs.getString("emp_name");
                	int leaves = rs.getInt("_leaves");
                	int month = rs.getInt("mon");
                	
                	Report report;
                	if(!reportMap.containsKey(empId)) {
                		report = new Report(empId, empName, deptName, month, leaves);
                		reportMap.put(empId, report);
                	} else {
                		report = reportMap.get(empId);
                		report.setTotalLeaves(month, leaves);
                		reportMap.put(empId, report);
                	}
                }
                session.setAttribute("deptYearlyReport", reportMap);
                session.setAttribute("deptReportType", "dept_yearly");
                response.sendRedirect("report.jsp");
        		
        	} catch(Exception e) {
        		System.out.println("Dept Yearly report error :"+e.getMessage());
        	}
        }
        else if(reportType.equals("dept_monthly")) {
        	String year = request.getParameter("yr");
        	String deptName = request.getParameter("dept_name");
        	int mon = Integer.parseInt(request.getParameter("month"));
        	
        	//Map<Integer, Report> reportMap = new HashMap<>();
        	try {
        		String query = "select e.emp_id, e.emp_name, e.dept_id, SUM(DATEDIFF(lr.end_date, lr.start_date)) as _leaves, MONTH(end_date) as mon "
        				+ "from Employee e inner join Department d on e.dept_id = d.dept_id "
        				+ "left join LeaveRecord lr on e.emp_id = lr.emp_id "
        				+ "where d.dept_name = ? and lr.status = 'approved' and MONTH(lr.end_date) = ? "
        				+ "group by e.emp_id, e.emp_name, e.dept_id, mon "
        				+ "order by _leaves desc";
        		ps = conn.prepareStatement(query);
        		ps.setString(1, deptName);
        		ps.setInt(2, mon);
        		rs = ps.executeQuery();
        		List<Report> reportList = new ArrayList<>();
                while(rs.next()) {
                	int empId = rs.getInt("emp_id");
                	String empName = rs.getString("emp_name");
                	int leaves = rs.getInt("_leaves");
                	int month = rs.getInt("mon");
                	
                	Report report = new Report(empId, empName, deptName, month, leaves, reportType);
                	reportList.add(report);

                }
                session.setAttribute("deptMonthlyReport", reportList);
                session.setAttribute("deptReportType", "dept_monthly");
                response.sendRedirect("report.jsp");
        		
        	} catch(Exception e) {
        		System.out.println("Dept Monthly report error : "+e.getMessage());
        	}
        }
    }
}
