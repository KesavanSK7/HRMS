

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;

/**
 * Servlet implementation class UpdateProfileServlet
 */
@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public UpdateProfileServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		HttpSession session = request.getSession();
		int modifier_id = (int)session.getAttribute("emp_id");
		int empId = Integer.parseInt(request.getParameter("emp_id"));
        String empName = request.getParameter("emp_name");
        Date dob = Date.valueOf(request.getParameter("DOB"));
        String gender = request.getParameter("gender");
        String phoneNumber = request.getParameter("phone_number");
        String email = request.getParameter("email");
        Date doj = Date.valueOf(request.getParameter("DOJ"));
        String qualification = request.getParameter("qualification");
        String experience = request.getParameter("experience");
        int yearOfExperience = Integer.parseInt(request.getParameter("year_of_experience"));

        Connection conn = DBConnection.getConnection();
        try {
            String sql = "UPDATE Employee SET emp_name = ?, DOB = ?, gender = ?, phone_number = ?, email = ?, DOJ = ?, qualification = ?, experience = ?, year_of_experience = ?, modified_by = ? WHERE emp_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, empName);
            ps.setDate(2, dob);
            ps.setString(3, gender);
            ps.setString(4, phoneNumber);
            ps.setString(5, email);
            ps.setDate(6, doj);
            ps.setString(7, qualification);
            ps.setString(8, experience);
            ps.setInt(9, yearOfExperience);
            ps.setInt(10, empId);
            ps.setInt(11, modifier_id);
            ps.executeUpdate();
            response.sendRedirect("home.jsp"); // Redirect to home page or appropriate page
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp"); // Redirect to error page
        }
	}

}
