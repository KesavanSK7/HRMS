

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;

import org.json.JSONObject;

import javax.servlet.http.*;

import java.sql.*;

/**
 * Servlet Filter implementation class DesignationFilter
 */
@WebFilter("/assigndesig")
public class DesignationFilter extends HttpFilter implements Filter {

    public DesignationFilter() {
        super();
    }

	public void destroy() {
		
	}
	
//	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//	    HttpServletRequest req = (HttpServletRequest) request;
//	    HttpServletResponse res = (HttpServletResponse) response;
//
//	    String contentType = req.getContentType();
//
//	    if ("application/json".equalsIgnoreCase(contentType)) {
//	        // Read the JSON body
//	        StringBuilder jsonBuffer = new StringBuilder();
//	        String line;
//	        try (BufferedReader reader = req.getReader()) {
//	            while ((line = reader.readLine()) != null) {
//	                jsonBuffer.append(line);
//	            }
//	        }
//
//	        String jsonString = jsonBuffer.toString();
//	        JSONObject requestJson = new JSONObject(jsonString);
//
//	        // Set email and desig_id as attributes
//	        req.setAttribute("email", requestJson.getString("email"));
//	        req.setAttribute("desig_id", requestJson.getInt("desig"));
//	    }
//
//	    // Pass the request along the filter chain
//	    chain.doFilter(request, response);
//	}

//
//	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//		HttpServletRequest req = (HttpServletRequest)request;
//		HttpServletResponse res = (HttpServletResponse)response;
//		HttpSession session = req.getSession();
//		
//		String contentType = req.getContentType();
//		String email = req.getParameter("email");
//		int desig_id = Integer.parseInt(req.getParameter("desig"));
//		
//		Connection conn = null;
//		try {
//			conn = DBConnection.getConnection();
//			PreparedStatement ps = conn.prepareStatement("select * from Designation where desig_id=?");
//			ps.setInt(1, desig_id);
//			ResultSet rs = ps.executeQuery();
//			if(rs.next()) {
//				chain.doFilter(request, response);
//			}
//			else {
//				System.out.println("No such designation");
//				session.setAttribute("desig_error", "There is no designation");
//				req.getRequestDispatcher("settings.jsp").forward(req, res);
//			}
//			
//			
//		} catch(Exception e) {
//			System.out.println(e.getMessage());
//		}
//		
//		//chain.doFilter(request, response);
//	}
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
	    HttpServletRequest req = (HttpServletRequest) request;
	    HttpServletResponse res = (HttpServletResponse) response;
	    HttpSession session = req.getSession();

	    String contentType = req.getContentType();

	    String email = null;
	    int desig_id = 0;

	    if ("application/json".equalsIgnoreCase(contentType)) {
	        StringBuilder jsonBuffer = new StringBuilder();
	        String line;
	        try (BufferedReader reader = req.getReader()) {
	            while ((line = reader.readLine()) != null) {
	                jsonBuffer.append(line);
	            }
	        }
	        String jsonString = jsonBuffer.toString();
	        JSONObject requestJson = new JSONObject(jsonString);

	        email = requestJson.getString("email");
	        desig_id = requestJson.getInt("desig");

	        req.setAttribute("email", email);
	        req.setAttribute("desig_id", desig_id);

	    } else if ("application/x-www-form-urlencoded".equalsIgnoreCase(contentType)) {
	        email = req.getParameter("email");
	        desig_id = Integer.parseInt(req.getParameter("desig"));

	        req.setAttribute("email", email);
	        req.setAttribute("desig_id", desig_id);
	    } else {
	        res.setStatus(HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE);
	        res.getWriter().write("Unsupported content type: " + contentType);
	        return;
	    }

	    Connection conn = null;
	    try {
	        conn = DBConnection.getConnection();
	        PreparedStatement ps = conn.prepareStatement("SELECT * FROM Designation WHERE desig_id = ?");
	        ps.setInt(1, desig_id);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            chain.doFilter(request, response);
	        } else {
	            if ("application/json".equalsIgnoreCase(contentType)) {
	                res.setContentType("application/json");
	                res.setCharacterEncoding("UTF-8");
	                JSONObject responseJson = new JSONObject();
	                responseJson.put("status", "failure");
	                responseJson.put("message", "No such designation");
	                res.getWriter().write(responseJson.toString());
	            } else {
	                session.setAttribute("desig_error", "There is no designation");
	                req.getRequestDispatcher("settings.jsp").forward(req, res);
	            }
	        }
	        
	    } catch (Exception e) {
	        System.out.println("Error: " + e.getMessage());
	    } finally {
	        if (conn != null) {
	            try {
	                conn.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}



	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
