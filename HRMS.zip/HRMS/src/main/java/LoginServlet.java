

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import abc.Employee;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		
		HttpSession session = request.getSession();
		response.setContentType("text/html");
		Connection conn = DBConnection.getConnection();
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		try {
		PreparedStatement ps = conn.prepareStatement("select emp_id, emp_name, pass from Employee where email = ?");
		ps.setString(1, email);
		ResultSet rs = ps.executeQuery();
		int emp_id = 0;
		String userpass = null;
		String emp_name = null;
		int rec = 0;
			while(rs.next()) {
				rec = 1;
				emp_id = rs.getInt("emp_id");
				emp_name = rs.getString("emp_name");
				userpass = rs.getString("pass");
				System.out.println("retrieved information");
			}
			if(rec==0) {
				System.out.println("User error");
				session.setAttribute("userError", "User not found");
				response.sendRedirect("index.jsp");
			}
			else {
				if(!pass.equals(userpass)) {
					System.out.println("Password error"+userpass + " "+pass);
					session.setAttribute("passError", "Password is wrong");
					RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
					rd.include(request, response);
				}
				else {
					System.out.println("Forward to home page");
					//response.getWriter().print("Welcome " + emp_name);
					session.setAttribute("emp_id", emp_id);
					session.setAttribute("emp_name", emp_name);
					session.setAttribute("email", email);
					
					Employee.sessionEmpId = emp_id;
					Employee.sessionEmpEmail = email;
					Employee.sessionEmpName = emp_name;
					RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
					rd.forward(request, response);
				}
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
