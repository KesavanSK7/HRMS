

import java.io.IOException;
import java.sql.*;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class DeptFilter
 */
@WebFilter("/createdept")
public class DeptFilter extends HttpFilter implements Filter {
	
    public DeptFilter() {
        super();
    }

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		HttpSession session = req.getSession();
		String deptName = req.getParameter("dept_name");
		String email = req.getParameter("manager_email");
		int desig_id = 0;
		
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("select * from Department where dept_name = ?");
			//PreparedStatement ps1 = conn.prepareStatement("select desig_id from Employee where email = ?");
			//PreparedStatement ps2 = conn.prepareStatement("select d.designation from Employee e inner join Designation d on e.? = d.? where e.email = ?");
			ps.setString(1, deptName);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("Department already exists");
				session.setAttribute("deptError", "Department already exists");
				req.getRequestDispatcher("settings.jsp").forward(req, res);
			}
//			ps1.setString(1, email);
//			rs = ps1.executeQuery();
//			if(rs.next()) {
//				desig_id = rs.getInt("desig_id");
//				ps2.setInt(1,desig_id);
//				ps2.setInt(2, desig_id);
//				ps2.setString(3, email);
//				rs = ps2.executeQuery();
//				if(rs.next()) {
//					chain.doFilter(request, response);
//				}
//				else {
//					System.out.println("Not a manager");
//					session.setAttribute("deptError", "Not a manager");
//					req.getRequestDispatcher("settings.jsp").forward(request, response);
//				}
//			}
			else {
				chain.doFilter(req, res);
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
