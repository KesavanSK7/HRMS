package abc;

import java.util.*;

public class Report {
    private int empId;
    private String empName;
    private int cl;
    private int sl;
    private int clu;
    private int slu;
    private Map<Integer, Integer> workingDays;
    private Map<Integer, Integer> lopDays;
    private int noOfLeaves;
    
    private String month;
    
    private String deptName;
    
    
    private Map<Integer, Integer> totalLeaves;

    public Report(int empId, String empName) {
        this.empId = empId;
        this.empName = empName;
        this.workingDays = new HashMap<>();
        this.lopDays = new HashMap<>();
    }
    
    public Report(int empId, String empName, int noOfLeaves) {
        this.empId = empId;
        this.empName = empName;
        this.setNoOfLeaves(noOfLeaves);
    }

    public Report(int empId, String empName, String deptName, int month, int leaves) {
		this.empId =  empId;
		this.empName = empName;
		this.setDeptName(deptName);
		this.totalLeaves = new HashMap<>();
		this.setTotalLeaves(month, leaves);
	}

	public Report(int empId, String empName, String deptName, int month, int leaves, String reportType) {
		this.empId =  empId;
		this.empName = empName;
		this.setDeptName(deptName);
		this.setMonth(month);
		this.setNoOfLeaves(leaves);
	}

	public int getEmpId() {
        return empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setWorkingDays(int month, int days) {
        this.workingDays.put(month, days);
    }

    public int getWorkingDays(int month) {
        return this.workingDays.getOrDefault(month, 0);
    }

    public void setLopDays(int month, int days) {
        this.lopDays.put(month, days);
    }

    public int getLopDays(int month) {
        return this.lopDays.getOrDefault(month, 0);
    }

	public int getCL() {
		return cl;
	}

	public void setCL(int cl) {
		this.cl = cl;
	}

	public int getSL() {
		return sl;
	}

	public void setSL(int sl) {
		this.sl = sl;
	}

	public int getClu() {
		return clu;
	}

	public void setClu(int clu) {
		this.clu = clu;
	}

	public int getSlu() {
		return slu;
	}

	public void setSlu(int slu) {
		this.slu = slu;
	}

	public int getNoOfLeaves() {
		return noOfLeaves;
	}

	public void setNoOfLeaves(int noOfLeaves) {
		this.noOfLeaves = noOfLeaves;
	}

	public int getTotalLeaves(int month) {
		return this.totalLeaves.getOrDefault(month, 0);
	}

	public void setTotalLeaves(int month, int days) {
		this.totalLeaves.put(month, days);
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(int month) {
		String[] months = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
		this.month = months[month-1];
	}


	
}
