package abc;

import java.sql.Date;
import java.sql.Time;
public class Shift {
    private int empId;
    private String shiftName;
    private Time startTime;
    private Time endTime;
    private Date startDate;
    private Date endDate;

    // Constructor
    public Shift(int empId, String shiftName, Time startTime, Time endTime, Date startDate, Date endDate) {
        this.empId = empId;
        this.shiftName = shiftName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Getters
    public int getEmpId() {
        return empId;
    }

    public String getShiftName() {
        return shiftName;
    }

    public Time getStartTime() {
        return startTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }
}

