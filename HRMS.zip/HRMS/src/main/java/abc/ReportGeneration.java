package abc;
import java.util.*;
import java.sql.*;

public class ReportGeneration {
	public static Map<Integer, Report> getMonthlyReport(int managerId) {
		Map<Integer, Report> reportMap = new HashMap<>();
		Connection conn = DBConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
		    // Query for getting CL and SL
		    String leaveBalQuery = "SELECT e.emp_id, e.emp_name, lb.leave_type, SUM(lb.leave_type_days) AS total_available_days "
		    		+ "FROM Employee e "
		    		+ "INNER JOIN LeaveBalance lb ON e.emp_id = lb.emp_id "
		    		+ "WHERE lb.leave_type IN ('CL', 'SL') AND e.manager_id = ? "
		    		+ "GROUP BY e.emp_id, e.emp_name, lb.leave_type";
		    ps = conn.prepareStatement(leaveBalQuery);
		    ps.setInt(1, managerId);
		    rs = ps.executeQuery();
		    
		    while(rs.next()) {
		    	int empId = rs.getInt("emp_id");
		        String empName = rs.getString("emp_name");
		        String leaveType = rs.getString("leave_type");
		        int totAvailDays = rs.getInt("total_available_days");
		        
		        Report report = reportMap.getOrDefault(empId, new Report(empId, empName));
		        if(leaveType.equals("CL"))
		        	report.setCL(totAvailDays);
		        else if(leaveType.equals("SL"))
		        	report.setSL(totAvailDays);
		        reportMap.put(empId, report);
		    }
		    
		    //Query for getting LeaveRecord leaves used
		    String leaveRecQuery = "SELECT e.emp_id, e.emp_name, lr.leave_type,"
		    		+ "SUM(DATEDIFF(lr.end_date, lr.start_date)) AS total_used_days "
		    		+ "FROM Employee e inner join LeaveRecord lr on e.emp_id = lr.emp_id "
		    		+ "where lr.leave_type in ('CL','SL') and lr.status = 'approved' and e.manager_id = ? "
		    		+ "GROUP BY e.emp_id, e.emp_name, lr.leave_type";
		    ps = conn.prepareStatement(leaveRecQuery);
		    ps.setInt(1, managerId);
		    rs = ps.executeQuery();
		    
		    while(rs.next()) {
		    	int empId = rs.getInt("emp_id");
		        String empName = rs.getString("emp_name");
		        String leaveType = rs.getString("leave_type");
		        int totUsedDays = rs.getInt("total_used_days");
		        
		        Report report = reportMap.getOrDefault(empId, new Report(empId, empName));
		        if(leaveType.equals("CL"))
		        	report.setClu(totUsedDays);
		        else if(leaveType.equals("SL"))
		        	report.setSlu(totUsedDays);
		        reportMap.put(empId, report);
		    }
		    
		    
		    // Query for Working Days
		    String workingDaysSQL = "SELECT e.emp_id, e.emp_name, MONTH(a.checkin_date) AS month, " +
		                            "COUNT(DISTINCT a.checkin_date) AS working_days " +
		                            "FROM Employee e JOIN Attendance a ON e.emp_id = a.emp_id " +
		                            "WHERE e.manager_id = ? " +
		                            "GROUP BY e.emp_id, e.emp_name, MONTH(a.checkin_date) " +
		                            "ORDER BY e.emp_id, month";
		    ps = conn.prepareStatement(workingDaysSQL);
		    ps.setInt(1, managerId);
		    rs = ps.executeQuery();

		    while (rs.next()) {
		        int empId = rs.getInt("emp_id");
		        String empName = rs.getString("emp_name");
		        int month = rs.getInt("month");
		        int workingDays = rs.getInt("working_days");

		        Report report = reportMap.getOrDefault(empId, new Report(empId, empName));
		        report.setWorkingDays(month, workingDays);
		        reportMap.put(empId, report);
		    }

		    rs.close();
		    ps.close();

		    // Query for Loss Of Pay Days
		    String lopSQL = "SELECT e.emp_id, e.emp_name, MONTH(lr.start_date) AS month, " +
		                    "SUM(datediff(lr.end_date,lr.start_date)) AS lop_days " +
		                    "FROM Employee e JOIN LeaveRecord lr ON e.emp_id = lr.emp_id " +
		                    "WHERE e.manager_id = ? AND lr.leave_type = 'LOP' " +
		                    "GROUP BY e.emp_id, e.emp_name, MONTH(lr.start_date) " +
		                    "ORDER BY e.emp_id, month";
		    ps = conn.prepareStatement(lopSQL);
		    ps.setInt(1, managerId);
		    rs = ps.executeQuery();

		    while (rs.next()) {
		        int empId = rs.getInt("emp_id");
		        int month = rs.getInt("month");
		        int lopDays = rs.getInt("lop_days");

		        Report report = reportMap.get(empId);
		        if (report != null) {
		            report.setLopDays(month, lopDays);
		        }
		    }

		} catch (SQLException e) {
		    e.printStackTrace();
		}
		return reportMap;
		
	}
	
	public static List<Report> getYearlyReport(int managerId){
		Connection conn = DBConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		List<Report> reportList = new ArrayList<>();
		try {
    		String userwiseQuery = "select e.emp_id, e.emp_name, sum(datediff(l.end_date, l.start_date)) as no_of_days from Employee e "
    				+"inner join LeaveRecord l on e.emp_id = l.emp_id "
    				+"where e.manager_id = ? and l.status = 'approved' "
    				+"group by e.emp_id, e.emp_name order by no_of_days desc ";
            ps = conn.prepareStatement(userwiseQuery);
            ps.setInt(1, managerId);
            rs = ps.executeQuery();
            
            //List<Report> reportList = new ArrayList<>();
            while(rs.next()) {
            	int empId = rs.getInt("emp_id");
            	int noOfDays = rs.getInt("no_of_days");
            	String empName = rs.getString("emp_name");
            	
            	Report report = new Report(empId, empName, noOfDays);
            	reportList.add(report);
            }
            
    	} catch (Exception e) {
    		System.out.println("Userwise report error :"+e.getMessage());
    	}
		 return reportList;
	}
}
