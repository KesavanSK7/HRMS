package abc;

import java.sql.*;
import java.util.List;

public class Attendance {
    private int attendanceId;
    private int empId;
    private Date checkinDate;
    private Date checkoutDate;
    private Time checkinTime;
    private Time checkoutTime;
    private String status;
	public int getAttendanceId() {
		return attendanceId;
	}
	public void setAttendanceId(int attendanceId) {
		this.attendanceId = attendanceId;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public Date getCheckinDate() {
		return checkinDate;
	}
	public void setCheckinDate(Date checkinDate) {
		this.checkinDate = checkinDate;
	}
	public Date getCheckoutDate() {
		return checkoutDate;
	}
	public void setCheckoutDate(Date checkoutDate) {
		this.checkoutDate = checkoutDate;
	}
	public Time getCheckinTime() {
		return checkinTime;
	}
	public void setCheckinTime(Time checkinTime) {
		this.checkinTime = checkinTime;
	}
	public Time getCheckoutTime() {
		return checkoutTime;
	}
	public void setCheckoutTime(Time checkoutTime) {
		this.checkoutTime = checkoutTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    
    
}
