package abc;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class ShiftGeneration {
	public static List<Shift> getShift(int empId){
		System.out.println("Manager ID:"+empId);
		List<Shift> shiftList = new ArrayList<>();

        // Fetch shift records from the database
        try {
        	Connection conn = DBConnection.getConnection();
        
        	String query = "SELECT e.emp_id,s.shift_name,s.start_time,s.end_time,s.from_date,s.to_date "
              		+ "FROM Employee e inner join Shift s on e.emp_id = s.emp_id "
              		+ "WHERE e.manager_id = ? "
              		+ "order by e.emp_id asc, s.from_date desc";
            PreparedStatement ps = conn.prepareStatement(query);

            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Shift shift = new Shift(
                    rs.getInt("emp_id"),
                    rs.getString("shift_name"),
                    rs.getTime("start_time"),
                    rs.getTime("end_time"),
                    rs.getDate("from_date"),
                    rs.getDate("to_date")
                );
                System.out.println("Getting records");
                shiftList.add(shift);
            }

        } catch (Exception e) {
            System.out.println("Error retrieving shift data");
        }
        return shiftList;
	}
}
