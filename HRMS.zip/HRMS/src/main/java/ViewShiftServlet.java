

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import abc.Shift;

import java.sql.*;
import java.util.*;

/**
 * Servlet implementation class ViewShiftServlet
 */
@WebServlet("/viewshift")
public class ViewShiftServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewShiftServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		HttpSession session = request.getSession();
		String error = "";
		error = AssignShiftFilter.myEmployee(request, response);
		if(!error.equals("")) {
			session.setAttribute("shiftError", error);
			request.getRequestDispatcher("shift.jsp").forward(request, response);
		}
		else {
            int empID = Integer.parseInt(request.getParameter("shift_emp_id"));
            List<Shift> shiftList = new ArrayList<>();

            // Fetch shift records from the database
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement("SELECT emp_id,shift_name,start_time,end_time,from_date,to_date FROM Shift WHERE emp_id = ?")) {

                ps.setInt(1, empID);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Shift shift = new Shift(
                        rs.getInt("emp_id"),
                        rs.getString("shift_name"),
                        rs.getTime("start_time"),
                        rs.getTime("end_time"),
                        rs.getDate("from_date"),
                        rs.getDate("end_date")
                    );
                    System.out.println("Getting records");
                    shiftList.add(shift);
                }

            } catch (Exception e) {
                System.out.println("Error retrieving shift data");
            }

            // Set shift data to request scope and forward to JSP
            request.setAttribute("shiftList", shiftList);
            request.getRequestDispatcher("shift.jsp").forward(request, response);
        }
		
	}

}
