

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import java.sql.*;

/**
 * Servlet implementation class CreateDeptServlet
 */
@WebServlet("/createdept")
public class CreateDeptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public CreateDeptServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		StringBuilder sb = new StringBuilder();
		BufferedReader reader = request.getReader();
		String line;
		while((line = reader.readLine()) != null) {
			sb.append(line);
		}
		
		JSONObject jsonObj = new JSONObject(sb.toString());
		String deptName = jsonObj.getString("dept_name");
		//String deptName = request.getParameter("dept_name");
		
		JSONObject responseJson = new JSONObject();
		
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("insert into Department(dept_name) values(?)");
			ps.setString(1,deptName);
			int r = ps.executeUpdate();
			if(r>0) {
				responseJson.put("status","success");
				responseJson.put("message", "Department created successfully");
			} else {
				responseJson.put("status","failure");
				responseJson.put("message", "Failed to create department");
			}
		} catch(Exception e) {
			responseJson.put("status","error");
			responseJson.put("message", "Error creating department :"+e.getMessage());
		}
		response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseJson.toString());
	}

}
