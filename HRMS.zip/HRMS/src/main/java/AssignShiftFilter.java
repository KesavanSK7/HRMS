

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import abc.Employee;

import java.sql.*;

/**
 * Servlet Filter implementation class AssignShiftFilter
 */
@WebFilter("/assignshift")
public class AssignShiftFilter extends HttpFilter implements Filter {
       
    public AssignShiftFilter() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void destroy() {
		// TODO Auto-generated method stub
	}
	public static String myEmployee(HttpServletRequest req, HttpServletResponse res) {
		int empID = Integer.parseInt(req.getParameter("shift_emp_id"));
		HttpSession session = req.getSession();
		//int assignerID = (int)session.getAttribute("emp_id");
		
		String assigner = req.getParameter("session_emp_id");
		int assignerID = 0;
		if("curr_emp".equals(assigner)) {
			assignerID = Employee.sessionEmpId;
			req.setAttribute("assigner_id", assignerID);
		}
		
		
		String error = "";
		
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("select * from Employee where emp_id = ?");
			ps.setInt(1, empID);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				ps = conn.prepareStatement("select manager_id from Employee where emp_id = ?");
				ps.setInt(1, empID);
				rs = ps.executeQuery();
				if(rs.next()) {
					int mId = rs.getInt("manager_id");
					if(mId!=assignerID) {
						error = "Not your employee";
					}
				}
			}
			else {
				error = "Invalid employee id";
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return error;
		
	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		HttpSession session = req.getSession();
		
		System.out.println("Start time :" + Time.valueOf(request.getParameter("start_time")+":00"));
		
		Time startTime = Time.valueOf(request.getParameter("start_time")+":00");
		Time endTime  = Time.valueOf(request.getParameter("end_time")+":00");
		Date startDate = Date.valueOf(request.getParameter("start_date"));
		Date endDate = Date.valueOf(request.getParameter("end_date"));
		String error = "";
		error = AssignShiftFilter.myEmployee(req, res);
		
		if(!error.equals("")) {
			session.setAttribute("shiftError", error);
			req.getRequestDispatcher("shift.jsp").forward(req, res);
		}
		
		else if(startTime.after(endTime)) {
			System.out.println("Start time should be less than end time");
			session.setAttribute("shiftError", "Start time should be less than end time");
			req.getRequestDispatcher("shift.jsp").forward(req, res);
		}
		else if(startDate.after(endDate)) {
			System.out.println("Start date should be less than end date");
			session.setAttribute("shiftError", "Start date should be less than end date");
			req.getRequestDispatcher("shift.jsp").forward(req, res);
		}
		else {
			chain.doFilter(request, response);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
