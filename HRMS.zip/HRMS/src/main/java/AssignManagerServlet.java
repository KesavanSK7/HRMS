

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

/**
 * Servlet implementation class AssignManagerServlet
 */
@WebServlet("/assignmanager")
public class AssignManagerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignManagerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    StringBuilder jsonBuffer = new StringBuilder();
	    String line;
	    try (BufferedReader reader = request.getReader()) {
	        while ((line = reader.readLine()) != null) {
	            jsonBuffer.append(line);
	        }
	    }

	    String jsonString = jsonBuffer.toString();
	    JSONObject requestJson = new JSONObject(jsonString);

	    String empEmail = requestJson.getString("emp_email");
	    String managerEmail = requestJson.getString("manager_email");
	    int managerID = 0;
	    Connection conn = null;

	    System.out.println("Employee Email: " + empEmail);
	    System.out.println("Manager Email: " + managerEmail);

	    JSONObject responseJson = new JSONObject();

	    try {
	        conn = DBConnection.getConnection();

	        PreparedStatement ps = conn.prepareStatement("SELECT emp_id FROM Employee WHERE email = ?");
	        ps.setString(1, managerEmail);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            managerID = rs.getInt("emp_id");
	            System.out.println("Got Manager ID: " + managerID);
	        }

	        if (managerID != 0) {
	            ps = conn.prepareStatement("UPDATE Employee SET manager_id = ? WHERE email = ?");
	            ps.setInt(1, managerID);
	            ps.setString(2, empEmail);
	            int rowsUpdated = ps.executeUpdate();

	            if (rowsUpdated > 0) {
	                System.out.println("Assigned manager successfully");
	                responseJson.put("status", "success");
	                responseJson.put("message", "Manager assigned successfully");
	            } else {
	                responseJson.put("status", "failure");
	                responseJson.put("message", "Failed to assign manager, no matching employee.");
	            }
	        } else {
	            responseJson.put("status", "failure");
	            responseJson.put("message", "Manager email not found.");
	        }

	        rs.close();
	        ps.close();

	    } catch (Exception e) {
	        System.out.println("Error: " + e.getMessage());
	        responseJson.put("status", "failure");
	        responseJson.put("message", "Error: " + e.getMessage());
	    } finally {
	        if (conn != null) {
	            try {
	                conn.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	    response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(responseJson.toString());
	}


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String empEmail = (String)request.getParameter("emp_email");
		String managerEmail = (String)request.getParameter("manager_email");
		int managerID = 0;
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("select emp_id from Employee where email = ?");
			ps.setString(1, managerEmail);
			ResultSet rs = ps.executeQuery();
			System.out.println("got Manager");
			if(rs.next()) {
				managerID = rs.getInt("emp_id");
			}
			if(managerID!=0) {
				ps = conn.prepareStatement("Update Employee set manager_id = ? where email = ?");
				ps.setInt(1, managerID);
				ps.setString(2, empEmail);
				ps.execute();
				System.out.println("Assigned manager successfully");
				response.sendRedirect("settings.jsp");
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

}
