

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.*;
import java.sql.Date;
import java.util.*;
import abc.Employee;

/**
 * Servlet implementation class OthersServlet
 */
@WebServlet("/others")
public class OthersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public OthersServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int reportEmpId = Integer.parseInt(request.getParameter("report_emp_id"));
		String type = request.getParameter("type");
		//System.out.println(type);
		
		if(type.equals("showReporters")) {
			showReporters(reportEmpId, request, response);
		}
	}
	
	private void showReporters(int reportEmpId, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection conn = null;
		JSONObject responseJson = new JSONObject();
		Map<Integer, List<Employee>> hierarchyMap = new TreeMap<>();
		try {
			conn = DBConnection.getConnection();
			String query = "WITH RECURSIVE EmployeeHierarchy AS ( "
					+ "    SELECT emp_id, emp_name, manager_id, 1 as level "
					+ "    FROM Employee WHERE manager_id = ?"
					+ "    UNION ALL "
					+ "    SELECT e.emp_id, e.emp_name, e.manager_id, level+1 "
					+ "    FROM Employee e INNER JOIN EmployeeHierarchy eh ON e.manager_id = eh.emp_id "
					+ ") "
					+ "SELECT emp_id, emp_name, manager_id, level\n"
					+ "FROM EmployeeHierarchy";
			
			String query2 = "WITH RECURSIVE EmployeeHierarchy AS (\n"
					+ "    SELECT e.emp_id, e.emp_name, e.manager_id, e1.emp_name as manager_name, 1 as level\n"
					+ "    FROM Employee e INNER JOIN Employee e1 on e1.emp_id = e.manager_id\n"
					+ "    WHERE e.manager_id = ?\n"
					+ "    UNION ALL\n"
					+ "    SELECT e.emp_id, e.emp_name, e.manager_id, e1.emp_name as manager_name, level+1\n"
					+ "    FROM Employee e INNER JOIN Employee e1 on e1.emp_id = e.manager_id\n"
					+ "    INNER JOIN EmployeeHierarchy eh ON e.manager_id = eh.emp_id\n"
					+ ")\n"
					+ "SELECT emp_id, emp_name, manager_id, manager_name, level\n"
					+ "FROM EmployeeHierarchy";
			//ps = conn.prepareStatement(query);
			ps = conn.prepareStatement(query2);
			ps.setInt(1, reportEmpId);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				int empId = rs.getInt("emp_id");
				int managerId = rs.getInt("manager_id");
				int level = rs.getInt("level");
				String empName = rs.getString("emp_name");
				String managerName = rs.getString("manager_name");
				
				//Employee emp = new Employee(empId, empName, managerId, level);
				Employee emp = new Employee(empId, empName, managerId, managerName, level);
				List<Employee> empList = hierarchyMap.getOrDefault(level, new ArrayList<>());
				empList.add(emp);
				hierarchyMap.put(level, empList);
			}
			// Convert hierarchyMap into a JSON object
	        JSONObject hierarchyJson = new JSONObject();
	        for (Map.Entry<Integer, List<Employee>> entry : hierarchyMap.entrySet()) {
	            int level = entry.getKey();
	            List<Employee> employees = entry.getValue();
	            
	            // Create a JSON array for employees at this level
	            JSONArray employeeArray = new JSONArray();
	            for (Employee employee : employees) {
	                JSONObject empJson = new JSONObject();
	                empJson.put("emp_id", employee.getEmpId());
	                empJson.put("emp_name", employee.getEmpName());
	                empJson.put("manager_id", employee.getManagerId());
	                empJson.put("manager_name", employee.getManagerName());
	                empJson.put("level", employee.getLevel());
	                employeeArray.put(empJson);
	            }

	            hierarchyJson.put("level_" + level, employeeArray);
	        }
	        responseJson.put("status", "success");
	        responseJson.put("hierarchy", hierarchyJson);
		}
         catch (Exception e) {
        	 responseJson.put("status", "error");
        	 responseJson.put("message", "Error while fetching hierarchy: " + e.getMessage());
         }
		
		response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseJson.toString());
		
	}

	HttpSession session = null;
	Connection conn = DBConnection.getConnection();
	PreparedStatement ps = null;
	ResultSet rs = null;
	int sessionId = 0;
	
	static Map<Integer, Employee> empMap = new HashMap<>(); 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		session = request.getSession();
		sessionId = (int)session.getAttribute("emp_id");
		
		String type = request.getParameter("input_type");
		System.out.println(type);
		if(type.equals("view_employee")) {
			System.out.println("View Employee");
			viewEmployee(request, response);
		} else if (type.equals("edit_employee")) {
            int empId = Integer.parseInt(request.getParameter("edit_emp_id"));
            loadEmployee(empId, request, response);
        } else if (type.equals("update_employee")) {
            updateEmployee(request, response);
        }
	}
	
	private void updateEmployee(HttpServletRequest request, HttpServletResponse response) {
	    
	    Employee emp = (Employee)session.getAttribute("editEmployee");
	    String gender = request.getParameter("gender");
	    if(!gender.equals("M") && !gender.equals("F"))
	    	gender = null;
	    
	    String phno = request.getParameter("phone_number");
	    if(!phno.equals("M") && !phno.equals("F"))
	    	phno = null;
	    
	    Date dob = null;
	    Date doj = null;
	    String dob1 = (String)request.getParameter("DOB");
	    String doj1 = (String)request.getParameter("DOJ"); 
	    
	    if(!dob1.equals(""))
	    	dob = Date.valueOf(request.getParameter("DOB"));
	    System.out.println("DOB :" + dob);
	    
	    if(!doj1.equals(""))
	    	doj = Date.valueOf(request.getParameter("DOJ"));
	    
	    String qualification = request.getParameter("qualification");
	    if(qualification.equals(""))
	    	qualification = null;
	    
	    String experience = request.getParameter("experience");
	    if(experience.equals(""))
	    	experience = null;
	    
	    String yoe1 = request.getParameter("year_of_experience");
	    int yoe = 0;
	    if(!yoe1.equals(""))
	    	yoe = Integer.parseInt(yoe1);
	    
	    System.out.println(gender);
	    
	    emp.setGender(gender);
	    emp.setPhoneNumber(phno);
	    emp.setDob(dob);
	    emp.setQualification(qualification);
	    emp.setExperience(experience);
	    emp.setYoe(yoe);
	    emp.setDoj(doj);
	    System.out.println(emp.getPhoneNumber()==null?"null":emp.getPhoneNumber());

	    try {
	    	String sql = "UPDATE Employee SET DOB = ?, gender = ?, "
	    			+ "phone_number = ?, DOJ = ?, qualification = ?, "
	    			+ "experience = ?, year_of_experience = ?, modified_by = ? "
	    			+ "WHERE emp_id = ?";
	        ps = conn.prepareStatement(sql);
	        ps.setDate(1, emp.getDob());
	        ps.setString(2,emp.getGender());
	        ps.setString(3, emp.getPhoneNumber());
	        ps.setDate(4, emp.getDoj());
	        ps.setString(5, emp.getQualification());
	        ps.setString(6, emp.getExperience());
	        ps.setInt(7, emp.getYoe());
	        ps.setInt(8, sessionId);
	        ps.setInt(9, emp.getEmpId());        
	        
	        int result = ps.executeUpdate();

	        if (result > 0) {
	            // Update successful, remove editEmployee from session
	            session = request.getSession();
	            session.removeAttribute("editEmployee");
	            response.sendRedirect("others.jsp"); // Reload the page
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		
	}

	private void loadEmployee(int empId, HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String empName = "";
        String email = "";
        String phoneNumber = "";
        String qualification = "";
        String experience = "";
        String gender = "";
        int yoe = 0;
        Date dob = null;
        Date doj = null;
		try {
	        ps = conn.prepareStatement("SELECT * FROM Employee WHERE emp_id = ?");
	        ps.setInt(1, empId);
	        rs = ps.executeQuery();

	        if (rs.next()) {
	        	empName = rs.getString("emp_name");
                email = rs.getString("email");
                phoneNumber = rs.getString("phone_number");
                qualification = rs.getString("qualification");
                experience = rs.getString("experience");
                gender = rs.getString("gender");
                dob = rs.getDate("DOB");
                doj = rs.getDate("DOJ");
                yoe = rs.getInt("year_of_experience");

	            Employee emp = new Employee(empId, empName, email);
	            emp.setPhoneNumber(phoneNumber);
	            emp.setQualification(qualification);
	            emp.setExperience(experience);
	            emp.setGender(gender);
	            emp.setDob(dob);
	            emp.setDoj(doj);
	            emp.setYoe(yoe);
	            

	            // Set editEmployee in session
	            session = request.getSession();
	            session.setAttribute("editEmployee", emp);
	        }

	        // Redirect with input_type parameter to display the form
	        response.sendRedirect("others.jsp?input_type=edit_employee"); 

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		
	}

	private void viewEmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		try {
			ps = conn.prepareStatement("SELECT emp_id, emp_name, email from Employee where manager_id = ?");
			ps.setInt(1, sessionId);
			rs = ps.executeQuery();
			
			List<Employee> empList = new ArrayList<>();
			while(rs.next()) {
				int empId = rs.getInt("emp_id");
				String empName = rs.getString("emp_name");
				String email = rs.getString("email");
				
				Employee emp = new Employee(empId, empName, email);
				if(!empMap.containsKey(empId)) {
					empMap.put(empId, emp);
					empList.add(emp);
				}
				//empList.add(emp);	
			}
			session.setAttribute("empList" ,empList);
			response.sendRedirect("others.jsp");
		} catch(Exception e) {
			System.out.println("View Employee error :"+e.getMessage());
		}
		
	}

}
