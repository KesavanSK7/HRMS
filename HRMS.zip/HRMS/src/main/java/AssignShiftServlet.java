

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;

/**
 * Servlet implementation class AssignShiftServlet
 */
@WebServlet("/assignshift")
public class AssignShiftServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignShiftServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		HttpSession session = request.getSession();
		//int assignerID = (int)session.getAttribute("emp_id");
		int assignerID = (int) request.getAttribute("assigner_id");
		int empID = Integer.parseInt(request.getParameter("shift_emp_id"));
		String shiftName = request.getParameter("shift_name");
		Time startTime = Time.valueOf(request.getParameter("start_time")+":00");
		Time endTime  = Time.valueOf(request.getParameter("end_time")+":00");
		Date startDate = Date.valueOf(request.getParameter("start_date"));
		Date endDate = Date.valueOf(request.getParameter("end_date"));
		System.out.println("Start time :" + startTime);
		System.out.println("End time :" + endTime);
		System.out.println("Start date :" + startDate);
		System.out.println("End date :" + endDate);
		System.out.println(assignerID);
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("insert into Shift(emp_id, shift_name, start_time, end_time, from_date, to_date, created_by) values(?,?,?,?,?,?,?)");
			ps.setInt(1, empID);
			ps.setString(2, shiftName);
			ps.setTime(3, startTime);
			ps.setTime(4, endTime);
			ps.setDate(5, startDate);
			ps.setDate(6, endDate);
			ps.setInt(7, assignerID);
			int r = ps.executeUpdate();
			if(r>0) {
				System.out.println("Shift inserted");
				response.sendRedirect("shift.jsp");
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		
	}

}
